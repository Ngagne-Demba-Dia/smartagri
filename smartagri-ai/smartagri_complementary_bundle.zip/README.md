# SmartAgri92 — Bundle Complémentaire

Ce bundle contient les actifs qui n'étaient PAS dans smartagri_complete_ai_bundle.zip (281 Ko).

## Contenu

- `1_documentation/` : documents .md manquants du premier bundle
- `3_metrics/` : tables d'erreurs par groupe (group_errors) manquantes
- `7_execution_logs/` : ZIPs d'exécution avec code et logs
- `8_configs/` : quality_issues.csv, inventaire_datasets.csv
- `9_app_source/` : manifeste des 19 fichiers source de l'App Demo
- `10_manifest/` : 94_missing_local_assets.md (cet inventaire)

## Fichiers volumineux (téléchargement séparé)

1. lgb_models_native.zip (54 Mo) — 15 modèles LightGBM SoilNowcast
2. octopus_import_bundle.zip (39 Mo) — Data Lake 28 datasets
3. SoilNowcast — LightGBM.zip (58 Mo) — Logs d'exécution complets

## Reconstruction complète

Avec ces 4-5 fichiers, SmartAgri92 est intégralement reconstructible :
1. smartagri_complete_ai_bundle.zip (281 Ko) — bundle principal
2. smartagri_complementary_bundle.zip (ce fichier) — compléments
3. lgb_models_native.zip (54 Mo) — modèles
4. octopus_import_bundle.zip (39 Mo) — données
5. (optionnel) SoilNowcast execution.zip (58 Mo) — logs training
