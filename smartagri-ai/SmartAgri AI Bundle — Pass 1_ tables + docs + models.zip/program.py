from pathlib import Path
import numpy as np
import pandas as pd
SEED = 42
rng = np.random.default_rng(SEED)
OUTPUT = Path("output")
OUTPUT.mkdir(exist_ok=True)
INPUTS = {key: str(Path("inputs") / key) for key in ['pf_0400f6345c6e476c9458d7e2', 'pf_e4d1474ecfc343eb985dd3db', 'pf_a2301d71eac04bb4b00555bd', 'pf_3114413445ac45e58de8365d', 'pf_3fe5d5440a6d49069850f08f', 'pf_633225b80e1043e7b8c37c60', 'pf_0dcdc3366f1d44bdabdc55e2', 'pf_c1e2e939b13f4b52b95a55c8', 'pf_eaab43a437ce4fd98e8aab4c', 'pf_67c4a322514b40ae97c9e338', 'pf_0f364ac85e064af2a8351df1', 'pf_ffe8be2fc7ba44fba4ad6295', 'pf_3e7e7ad8ef744a279f4fd16b', 'pf_5cf29ec2a5e24af4b1f3b4ab', 'pf_6f931b49d0b74134a5d02993', 'pf_c03964b001d14c57919e486b', 'dat_ab646db01ad5', 'dat_8a25b526a892', 'dat_1b06400c0a9d', 'dat_b5a270a6e205', 'dat_b2bfe7c25bd3', 'dat_dedbae9f26dc', 'dat_0927e7a5f87c', 'dat_266cbb9747a3', 'dat_36b2d399d572', 'dat_f3036f2fb909', 'dat_960302d77246', 'dat_cc168f5c1214', 'dat_0ab56260700f', 'dat_b0e0cff523e1', 'dat_aef8044c0a30', 'dat_7764b6dc996a']}
def progress(message="", **fields):
    import json as _j, sys as _s, time as _t
    try:
        _r = dict(fields, message=str(message)[:200], t=round(_t.time(), 2))
        _l = _j.dumps(_r, default=str)
        print("[progress] " + _l, flush=True)
        with open(OUTPUT / ".progress.jsonl", "a") as _f:
            _f.write(_l + "\n")
    except Exception:
        pass
def _rt_setup():
    import json as _j, sys as _s
    here = globals().get("__file__")
    try:
        pd.set_option("future.infer_string", False)
        _select = pd.DataFrame.select_dtypes

        def select_dtypes(self, include=None, exclude=None):
            def classic(value):
                if value is None:
                    return None
                items = list(value) if isinstance(value, (list, tuple, set, frozenset)) else [value]
                out = []
                for item in items:
                    if item is str or (isinstance(item, str) and item in ("str", "string")):
                        out.append(object)
                        if item == "string":
                            out.append(item)
                    else:
                        out.append(item)
                return [x for i, x in enumerate(out) if not any(x is y for y in out[:i])]
            return _select(self, include=classic(include), exclude=classic(exclude))
        pd.DataFrame.select_dtypes = select_dtypes
    except Exception:
        pass
    _base = _j.JSONEncoder.default

    def default(self, value):
        if isinstance(value, np.generic):
            return value.item()
        if isinstance(value, np.ndarray):
            return value.tolist()
        if isinstance(value, (pd.Series, pd.Index)):
            return value.tolist()
        if isinstance(value, pd.DataFrame):
            return value.to_dict(orient="records")
        if isinstance(value, (pd.Timestamp, pd.Timedelta, Path)):
            return str(value)
        if isinstance(value, (set, frozenset)):
            return sorted(value, key=str)
        if value is pd.NA or value is pd.NaT:
            return None
        return _base(self, value)
    _j.JSONEncoder.default = default

    def diagnose(kind, error, tb):
        import re as _r, difflib as _d
        lines, message, frames, seen = [], str(error), [], set()

        def collect(space):
            for key, value in list(space.items()):
                if isinstance(value, pd.DataFrame) and id(value) not in seen and not str(key).startswith("_"):
                    seen.add(id(value))
                    frames.append((str(key), value))
        step = tb
        while step is not None:
            if step.tb_frame.f_code.co_filename == here:
                collect(step.tb_frame.f_locals)
            step = step.tb_next
        collect(globals())
        frames = frames[:8]

        def text_columns(frame):
            return [c for c in frame.columns if not (pd.api.types.is_numeric_dtype(frame[c])
                    or pd.api.types.is_bool_dtype(frame[c]) or pd.api.types.is_datetime64_any_dtype(frame[c]))]
        if "could not convert string to" in message:
            told = {}
            for label, frame in frames:
                columns = tuple(str(c) for c in text_columns(frame))
                if columns:
                    told.setdefault(columns, []).append((label, frame))
            value = _r.search(r"could not convert string to \w+: '?([^']*)'?", message)
            value = value.group(1) if value else None
            for columns, where in list(told.items())[:2]:
                frame = where[0][1]
                holds = [c for c in columns if value and c in frame.columns
                         and bool((frame[c].astype(str) == value).any())]
                if holds:
                    lines.append(f"{value!r} is a value of column {', '.join(holds[:3])}.")
                shown = "; ".join(
                    f"{c} (values: {', '.join(str(v)[:24] for v in frame[c].dropna().unique()[:4])})"
                    for c in columns[:8])
                lines.append(
                    f"Text columns in {', '.join(label for label, _ in where[:4])}: {shown}. They reached a model "
                    "that needs numbers. Encode exactly these columns by name inside the model pipeline "
                    "(ColumnTransformer with OneHotEncoder(handle_unknown='ignore'), fitted on the training rows "
                    "only), or leave them out of the features. A table read back from CSV holds the text again: "
                    "an encoding done in an earlier call is not in the file unless the encoded columns were saved.")
        if kind.__name__ == "KeyError" and error.args and isinstance(error.args[0], str):
            key = error.args[0]
            for label, frame in frames[:3]:
                names = [str(c) for c in frame.columns]
                if key not in names:
                    close = _d.get_close_matches(key, names, n=4, cutoff=0.5)
                    lines.append(f"{label} has no column {key!r}."
                                 + (f" Nearest names: {', '.join(close)}." if close else "")
                                 + f" Its columns: {', '.join(names[:60])}.")
            try:
                if key not in INPUTS and not lines:
                    lines.append("INPUTS holds: " + ", ".join(sorted(str(k) for k in INPUTS)[:30]) + ".")
            except Exception:
                pass
        if "NaN" in message or "missing values" in message or "infinity" in message:
            for label, frame in frames[:4]:
                empty = frame.isna().sum()
                empty = empty[empty > 0].sort_values(ascending=False)
                if len(empty):
                    lines.append(f"Missing values in {label}: "
                                 + ", ".join(f"{c} {int(n)}" for c, n in empty.head(10).items()) + ".")
        if kind.__name__ == "NameError":
            lines.append("Every call is a new program: variables, fitted models and imports of an earlier call do "
                         "not exist here. Define the name in this program, or read what an earlier call saved "
                         "from INPUTS by its file name.")
        if "inconsistent numbers of samples" in message or "shape" in message.lower() or "feature names" in message.lower():
            if frames:
                lines.append("Shapes: " + ", ".join(f"{label} {tuple(frame.shape)}" for label, frame in frames) + ".")
        try:
            from importlib import metadata as _m
            found = []
            for library in ("pandas", "numpy", "scikit-learn", "xgboost", "lightgbm", "catboost", "optuna",
                            "scipy", "matplotlib"):
                try:
                    found.append(library + " " + _m.version(library))
                except Exception:
                    pass
            if found:
                lines.append("Installed versions: " + ", ".join(found) + ".")
        except Exception:
            pass
        return lines

    def stopped(kind, error, tb):
        import traceback as _t
        _t.print_exception(kind, error, tb)
        try:
            for line in diagnose(kind, error, tb):
                print("[diagnosis] " + str(line)[:900], file=_s.stderr)
        except Exception:
            pass
        _s.stderr.flush()
    _s.excepthook = stopped


_rt_setup()

import zipfile, pathlib, json

zpath = OUTPUT / "partial_bundle_p1.zip"
manifest = {"tables": [], "documents": [], "models": [], "configs": [], "figures": [], "other": []}

with zipfile.ZipFile(zpath, 'w', zipfile.ZIP_DEFLATED) as zf:

    # ── 1. TABLES (metrics) ──────────────────────────────────────
    table_names = [
        "soilnowcast_all_metrics.csv", "soilnowcast_feature_importance_all.csv",
        "soilnowcast_group_errors.csv", "wx_rain_prob_all_metrics.csv",
        "wx_rain_prob_feature_importance_all.csv", "wx_rain_prob_shap_summary.csv",
        "wx_rain_prob_fold_stability.csv", "wx_rain_prob_group_errors.csv",
        "et0_forecast_all_metrics.csv", "et0_forecast_feature_importance.csv",
        "et0_forecast_group_errors.csv", "yield_forecast_all_metrics.csv",
        "yield_forecast_feature_importance.csv", "price_forecast_all_metrics.csv",
        "price_forecast_feature_importance.csv", "price_forecast_group_errors.csv"
    ]
    for i, tname in enumerate(table_names):
        if tname in INPUTS:
            p = pathlib.Path(INPUTS[tname])
            try:
                df = pd.read_parquet(p) if p.suffix == '.parquet' else pd.read_csv(p)
                buf = df.to_csv(index=False)
                # Route to correct subfolder
                if 'shap' in tname:
                    zf.writestr(f"4_shap/{tname}", buf)
                elif 'feature_importance' in tname:
                    zf.writestr(f"5_features/{tname}", buf)
                else:
                    zf.writestr(f"3_metrics/{tname}", buf)
                manifest["tables"].append({"name": tname, "rows": len(df), "cols": len(df.columns)})
                progress(f"Table {tname}", done=i+1, total=16)
            except Exception as e:
                print(f"WARN table {tname}: {e}")
        else:
            print(f"MISS table: {tname}")

    # ── 2. DOCUMENTS (.md) ───────────────────────────────────────
    doc_map = {
        "56_real_ai_portfolio.md": "pf_0400f6345c6e476c9458d7e2",
        "56_classe_a_fiches_detaillees.md": "pf_e4d1474ecfc343eb985dd3db",
        "57_first_octopus_projects.md": "pf_a2301d71eac04bb4b00555bd",
        "58_plan_A1_soil_nowcast.md": "pf_3114413445ac45e58de8365d",
        "80_smartagri_ai_orchestrator.md": "pf_3fe5d5440a6d49069850f08f",
        "81_ai_execution_flows.md": "pf_633225b80e1043e7b8c37c60",
        "82_class_b_readiness.md": "pf_0dcdc3366f1d44bdabdc55e2",
        "rapport_analyse_bundle_smartagri92.md": "pf_c1e2e939b13f4b52b95a55c8",
    }
    for dname, did in doc_map.items():
        if did in INPUTS:
            p = pathlib.Path(INPUTS[did])
            data = p.read_bytes()
            zf.writestr(f"1_documentation/{dname}", data)
            manifest["documents"].append({"name": dname, "bytes": len(data)})

    # ── 3. MODELS (small ZIPs) ───────────────────────────────────
    model_map = {
        "A2_ET0_Forecast_models.zip": "pf_ffe8be2fc7ba44fba4ad6295",
        "A3_Yield_A5_Price_models.zip": "pf_3e7e7ad8ef744a279f4fd16b",
        "A6_A7_A9_models.zip": "pf_5cf29ec2a5e24af4b1f3b4ab",
    }
    for mname, mid in model_map.items():
        if mid in INPUTS:
            data = pathlib.Path(INPUTS[mid]).read_bytes()
            zf.writestr(f"2_models/{mname}", data)
            manifest["models"].append({"name": mname, "bytes": len(data)})

    # ── 4. CONFIGS ────────────────────────────────────────────────
    cfg_map = {
        "lgb_config.json": "pf_eaab43a437ce4fd98e8aab4c",
        "analysis_part1.json": "pf_0f364ac85e064af2a8351df1",
    }
    for cname, cid in cfg_map.items():
        if cid in INPUTS:
            data = pathlib.Path(INPUTS[cid]).read_bytes()
            zf.writestr(f"8_configs/{cname}", data)
            manifest["configs"].append({"name": cname, "bytes": len(data)})

    # ── 5. FIGURES ────────────────────────────────────────────────
    fig_id = "pf_67c4a322514b40ae97c9e338"
    if fig_id in INPUTS:
        data = pathlib.Path(INPUTS[fig_id]).read_bytes()
        zf.writestr("4_shap/lgb_feature_importance.png", data)
        manifest["figures"].append({"name": "lgb_feature_importance.png", "bytes": len(data)})

    # ── 6. EXTRA CSVs ────────────────────────────────────────────
    for ename, eid in [("quality_issues.csv", "pf_6f931b49d0b74134a5d02993"),
                        ("inventaire_datasets.csv", "pf_c03964b001d14c57919e486b")]:
        if eid in INPUTS:
            data = pathlib.Path(INPUTS[eid]).read_bytes()
            zf.writestr(f"3_metrics/{ename}", data)
            manifest["other"].append({"name": ename})

    zf.writestr("_manifest_p1.json", json.dumps(manifest, indent=2, ensure_ascii=False))

sz = zpath.stat().st_size
total_files = sum(len(v) for v in manifest.values())
print(f"Pass 1 ZIP: {sz/1024:.1f} Ko, {total_files} fichiers")
for section, items in manifest.items():
    if items:
        print(f"  {section}: {len(items)}")
print(f"\nINPUTS keys: {sorted(INPUTS.keys())}")

