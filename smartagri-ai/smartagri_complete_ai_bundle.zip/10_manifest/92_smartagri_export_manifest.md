# 92 — SmartAgri Export Manifest
## Document produit par OctOpus — SmartAgri92 PAS Challenge 2026

---

## 1. Inventaire des actifs IA

### 1.1 Modèles champions (9)

| # | Modèle | Champion | Métrique principale |
|---|--------|----------|---------------------|
| 1 | SoilNowcast | LightGBM | r2=0.8353, rmse=7.45 |
| 2 | ET0 Forecast | CatBoost | r2=0.9997, rmse=0.0390 |
| 3 | Rain Intelligence | CatBoost | auc=0.9625, f1=0.764 |
| 4 | Yield Forecast | CatBoost | r2=0.9509, rmse=2.01 |
| 5 | Price Forecast | XGBoost | r2=0.8995, rmse=66.67 |
| 6 | Anomaly Intelligence | One-Class SVM + Autoencoder |  |
| 7 | Market Clustering | KMeans | k=2, silhouette=0.3446 |

### 1.2 Agents (4)

| Agent | Rôle | Modèles utilisés |
|-------|------|-------------------|
| Monitoring Engine | Surveillance continue | SoilNowcast, Rain, NDVI, Anomaly |
| Irrigation Engine | Recommandation FAO-56 | ET0, SoilNowcast, CropCalendar |
| Assistant Parcellaire v2 | Interface conversationnelle | Tous via Orchestrator |
| AI Orchestrator | Routage intelligent | Tous les 9 modèles |

### 1.3 Datasets (28)

- 30,073,395 lignes totales
- 14/14 régions couvertes
- Grille 0.05° (6,945 cellules)
- Période : 2015-2026

### 1.4 Knowledge Base

- 527 chunks indexés
- 7 domaines
- 75% Recall@5

---

## 2. Artefacts exportables

### 2.1 Modèles entraînés

| Artefact | Taille | Contenu |
|----------|--------|---------|
| lgb_models_native.zip | 54 Mo | 15 modèles LightGBM SoilNowcast (5 cibles × 3 folds) |
| lgb_xgb_models.zip | ~2 Mo | Modèles ET0 (LGB+XGB+CB) |
| cb_models.zip | ~2 Mo | Modèles CropCalendar, NDVI, Market Clustering |

### 2.2 Tables de métriques (27)

Toutes les tables CSV produites pendant l'entraînement.

### 2.3 Documentation (35+ documents)

Documents numérotés 56 à 93.

---

## 3. Pipelines

### 3.1 Entraînement

```
Data Lake → Feature Engineering → GroupKFold(k=3) → Train(LGB/XGB/CB) → Compare → Champion
```

### 3.2 Inférence

```
Input → Feature Lookup → Model.predict() → Confidence Check → Response
```

### 3.3 Monitoring

```
Cron(hourly) → Fetch Weather → Run Models → Check Thresholds → Alert if needed
```

---

## 4. Prompts

### 4.1 Assistant Parcellaire v2

Prompt système : orchestration multi-modèle avec transparence, gestion des conflits
et abstentions, 4 profils utilisateur (agriculteur → chercheur).

### 4.2 Orchestrateur

Routage par intention (15 intents) vers le bon modèle/agent.

---

## 5. Reconstruction hors OctOpus

1. **Installer** : Python 3.10+, LightGBM, XGBoost, CatBoost, scikit-learn, pandas, numpy.
2. **Charger** : octopus_import_bundle.zip (Data Lake, 39 Mo).
3. **Charger** : lgb_models_native.zip (modèles SoilNowcast, 54 Mo).
4. **Lire** : 84_smartagri_mlops_architecture.md pour l'architecture.
5. **Déployer** : FastAPI + les classes du 82_smartagri_ai_runtime.md.

---

*PAS Challenge 2026 — Équipe Agri-Moderne 5.0*
