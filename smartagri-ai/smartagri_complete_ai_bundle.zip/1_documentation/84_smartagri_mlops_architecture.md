# 84 — SmartAgri MLOps Architecture
## Document produit par OctOpus — SmartAgri92 PAS Challenge 2026

---

## 1. Vue d'ensemble

SmartAgri MLOps est l'infrastructure de production qui opère les 9 modèles IA
entraînés dans le cadre du projet SmartAgri92.

### 1.1 Modèles en production

| # | Modèle | Champion | Métrique principale |
|---|--------|----------|---------------------|
| 1 | SoilNowcast | LightGBM | r2=0.8353, rmse=7.45 |
| 2 | ET0 Forecast | CatBoost | r2=0.9997, rmse=0.0390 |
| 3 | Rain Intelligence | CatBoost | auc=0.9625, f1=0.764 |
| 4 | Yield Forecast | CatBoost | r2=0.9509, rmse=2.01 |
| 5 | Price Forecast | XGBoost | r2=0.8995, rmse=66.67 |
| 6 | Anomaly Intelligence | One-Class SVM + Autoencoder |  |
| 7 | Market Clustering | KMeans | k=2, silhouette=0.3446 |

### 1.2 Principes architecturaux

1. **Immutabilité des artefacts** : chaque modèle est versionné avec son hash SHA-256.
2. **Séparation entraînement / inférence** : pipelines distincts.
3. **Reproductibilité** : seed=42, GroupKFold par power_cell_id.
4. **Monitoring continu** : drift détecté sur les features et les prédictions.

---

## 2. Feature Store

### 2.1 Architecture

```
┌─────────────────────────────────────────────┐
│              Feature Store                   │
│                                              │
│  ┌──────────┐  ┌──────────┐  ┌───────────┐  │
│  │ Raw      │→ │ Engineered│→ │ Serving   │  │
│  │ Features │  │ Features  │  │ Features  │  │
│  └──────────┘  └──────────┘  └───────────┘  │
└─────────────────────────────────────────────┘
```

### 2.2 Sources de données

| Source | Fréquence | Lignes | Clé spatiale |
|--------|-----------|--------|--------------|
| NASA POWER | Quotidien | 329,232 | power_cell_id |
| CHIRPS v3 | Quotidien | 28,953,705 | cell_id (0.05°) |
| FAO56 ET0 | Quotidien | 329,232 | power_cell_id |
| NASA Soil Wetness | Quotidien | 329,232 | power_cell_id |
| iSDAsoil | Statique | 13,890 | cell_id |
| ESA WorldCover | Statique | 6,945 | cell_id |
| WFP Food Prices | Mensuel | 55,283 | market_id |
| FAOSTAT Yields | Annuel | 956 | national |
| Sentinel-2 NDVI | Mensuel | 26,198 | cell_id |

### 2.3 Features engineered

- Rolling sums : rain_sum_3d, rain_sum_7d, rain_sum_14d (NASA + CHIRPS)
- ET0 rolling mean : et0_pm_mean_7d
- Cycliques : doy_sin, doy_cos
- Pédologiques : sand_pct, clay_pct, soc_g_kg, ph_h2o, bulk_density
- PTF : fc_ptf_pct, wp_ptf_pct
- Land cover : share_crop, share_tree, share_bare, share_built

---

## 3. Model Registry

### 3.1 Structure

```
model_registry/
├── soilnowcast/
│   ├── v1/
│   │   ├── model_lgb_fold0.pkl
│   │   ├── model_lgb_fold1.pkl
│   │   ├── ...
│   │   ├── metadata.json
│   │   └── metrics.json
├── rain_intelligence/
│   ├── v1/
│   │   ├── model_catboost_fold0.cbm
│   │   └── ...
├── et0_forecast/
├── yield_forecast/
├── price_forecast/
├── crop_calendar/
├── ndvi_anomaly/
├── anomaly_intelligence/
└── market_clustering/
```

### 3.2 Cycle de vie

```
Development → Staging → Champion → Archived
     │            │         │
     └── Challenger ────────┘
```

### 3.3 Promotion criteria

| Critère | Seuil |
|---------|-------|
| R² (régression) | > champion - 0.01 |
| AUC (classification) | > champion - 0.005 |
| F1 (classification) | > champion - 0.01 |
| Latence p99 | < 100ms |
| Taille modèle | < 50 Mo |

---

## 4. Pipeline d'entraînement

```
Data Lake → Feature Store → Split (GroupKFold k=3)
                                    │
                            ┌───────┴───────┐
                            │   LightGBM    │
                            │   XGBoost     │
                            │   CatBoost    │
                            └───────┬───────┘
                                    │
                            Comparison → Champion Selection
                                    │
                            Registry → Deployment
```

### 4.1 Hyperparamètres de référence

**LightGBM (SoilNowcast)**
```json
{
  "n_estimators": 2000,
  "learning_rate": 0.05,
  "max_depth": 8,
  "num_leaves": 127,
  "subsample": 0.8,
  "colsample_bytree": 0.8,
  "min_child_samples": 50,
  "reg_alpha": 0.1,
  "reg_lambda": 1.0
}
```

**CatBoost (Rain Intelligence)**
```json
{
  "iterations": 2000,
  "learning_rate": 0.05,
  "depth": 8,
  "l2_leaf_reg": 3,
  "subsample": 0.8
}
```

---

## 5. Pipeline d'inférence

```
API Request → Feature Lookup → Model Predict → Post-process → Response
                  │                                    │
            Feature Store                      Confidence check
                                               Abstention rules
```

### 5.1 Latence cible

| Modèle | Latence p50 | Latence p99 |
|--------|-------------|-------------|
| SoilNowcast | < 10ms | < 50ms |
| Rain Intelligence | < 10ms | < 50ms |
| ET0 Forecast | < 5ms | < 20ms |
| Yield Forecast | < 5ms | < 20ms |
| Price Forecast | < 5ms | < 20ms |

---

## 6. Monitoring & Drift Detection

### 6.1 Feature drift

- **Méthode** : PSI (Population Stability Index) sur fenêtre glissante 30 jours.
- **Seuil warning** : PSI > 0.1
- **Seuil critical** : PSI > 0.2

### 6.2 Prediction drift

- **Méthode** : KS test sur les distributions de prédictions.
- **Seuil** : p-value < 0.01

### 6.3 Performance monitoring

- **Méthode** : comparaison R²/AUC mesurés vs baseline.
- **Seuil retraining** : dégradation > 5% relative.

---

## 7. Retraining Strategy

### 7.1 Déclencheurs

| Déclencheur | Condition | Action |
|-------------|-----------|--------|
| Calendrier | Mensuel | Retraining complet |
| Drift feature | PSI > 0.2 | Retraining ciblé |
| Drift prediction | KS p < 0.01 | Investigation + retraining |
| Dégradation perf | > 5% relatif | Retraining urgent |
| Nouvelles données | Volume > 10% | Retraining incrémental |

### 7.2 Procédure

1. Snapshot des données actuelles.
2. Entraînement des 3 candidats (LGB/XGB/CB).
3. Évaluation sur holdout spatial (Mboro, Potou, Richard-Toll).
4. Comparison avec champion actuel.
5. Promotion si critères satisfaits.
6. Rollback automatique si dégradation en production.

---

## 8. Infrastructure cible

```
┌─────────────────────────────────────────────────┐
│                  SmartAgri MLOps                  │
│                                                   │
│  ┌─────────┐  ┌──────────┐  ┌────────────────┐  │
│  │ Feature │  │  Model   │  │  Monitoring    │  │
│  │ Store   │  │ Registry │  │  & Alerting    │  │
│  └────┬────┘  └────┬─────┘  └───────┬────────┘  │
│       │            │                │            │
│  ┌────┴────────────┴────────────────┴──────┐    │
│  │          Inference Engine                │    │
│  │   (FastAPI + Redis + Model Workers)     │    │
│  └─────────────────────────────────────────┘    │
│                                                   │
│  ┌─────────────────────────────────────────┐     │
│  │        Training Pipeline                 │     │
│  │   (Airflow + MLflow + GPU Workers)      │     │
│  └─────────────────────────────────────────┘     │
└─────────────────────────────────────────────────┘
```

---

## 9. Stack technique

| Composant | Technologie |
|-----------|-------------|
| Feature Store | Feast / Redis |
| Model Registry | MLflow |
| Orchestration | Airflow |
| Serving | FastAPI + Uvicorn |
| Monitoring | Prometheus + Grafana |
| Alerting | PagerDuty / Slack |
| Storage | MinIO / S3 |
| CI/CD | GitHub Actions |

---

## 10. Sécurité & Gouvernance

- **Accès** : RBAC par rôle (data scientist, ML engineer, ops).
- **Audit** : logs immuables de chaque prédiction.
- **Données** : pseudonymisation HMAC-SHA256 des identifiants spatiaux.
- **Holdout** : zones de validation (Mboro, Potou, Richard-Toll) strictement exclues de l'entraînement.
- **Licences** : toutes les données sont open data (CC BY 4.0, NASA Open Data, CC BY-IGO 3.0).

---

*Document généré automatiquement à partir des métriques mesurées du projet SmartAgri92.*
*PAS Challenge 2026 — Équipe Agri-Moderne 5.0*
