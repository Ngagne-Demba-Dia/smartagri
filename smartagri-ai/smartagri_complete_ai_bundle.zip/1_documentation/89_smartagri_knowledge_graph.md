# 89 — SmartAgri Knowledge Graph
## Document produit par OctOpus — SmartAgri92 PAS Challenge 2026

---

## 1. Vue d'ensemble

Le Knowledge Graph SmartAgri est une représentation relationnelle de l'ensemble
des connaissances agricoles, climatiques et IA du système.

### 1.1 Statistiques

| Métrique | Valeur |
|----------|--------|
| Chunks indexés | 527 |
| Domaines couverts | 7 |
| Recall@5 (évaluation) | 75% |
| Modèles IA connectés | 9 |
| Agents connectés | 4 |
| Régions couvertes | 14/14 |

---

## 2. Types de nœuds

| # | Type | Nombre estimé | Description |
|---|------|---------------|-------------|
| 1 | Region | 14 | Régions administratives du Sénégal |
| 2 | Cell | 6,945 | Cellules grille 0.05° |
| 3 | PowerCell | 76 | Mailles NASA POWER 0.5°×0.625° |
| 4 | Market | 79 | Marchés WFP géolocalisés |
| 5 | Crop | 17 | Cultures (7 maraîchères + 10 céréalières) |
| 6 | SoilType | ~30 | Types de sol (iSDAsoil) |
| 7 | Model | 9 | Modèles IA champion |
| 8 | Agent | 4 | Monitoring, Irrigation, Assistant, Orchestrator |
| 9 | Document | 35+ | Documents techniques (56-93) |
| 10 | KnowledgeChunk | 527 | Fragments de connaissances indexés |
| 11 | Dataset | 28 | Jeux de données source |

**Total estimé : ~7,800 nœuds**

---

## 3. Types de relations

### 3.1 Relations spatiales

```
Region ──contains──→ Cell
Region ──contains──→ Market
Cell ──belongs_to──→ PowerCell
Cell ──has_soil──→ SoilType
Cell ──grows──→ Crop
Market ──serves──→ Region
```

### 3.2 Relations temporelles

```
Cell ──measured_at(date)──→ WeatherObs
Cell ──measured_at(date)──→ RainObs
Cell ──measured_at(date)──→ NDVIObs
Market ──priced_at(date)──→ PriceObs
```

### 3.3 Relations agronomiques

```
Crop ──needs_water──→ ETc(Kc × ET0)
Crop ──grows_in──→ SoilType
Crop ──season──→ CropCalendar
Cell ──irrigation_need──→ Crop
```

### 3.4 Relations IA

```
Model ──predicts──→ Cell (SoilNowcast, Rain, ET0, NDVI)
Model ──predicts──→ Market (Price)
Model ──predicts──→ Crop (Yield, CropCalendar)
Agent ──uses──→ Model
Agent ──monitors──→ Cell
Agent ──recommends──→ Action
```

### 3.5 Relations documentaires

```
KnowledgeChunk ──extracted_from──→ Document
KnowledgeChunk ──covers──→ Domain
Document ──describes──→ Model
Document ──describes──→ Agent
```

---

## 4. Domaines de connaissances

| Domaine | Chunks | Sources principales |
|---------|--------|---------------------|
| Climat & Météo | ~80 | NASA POWER, CHIRPS |
| Sol & Pédologie | ~70 | iSDAsoil, SoilGrids |
| Irrigation | ~75 | FAO-56, Penman-Monteith |
| Cultures | ~80 | FAOSTAT, calendriers culturaux |
| Marchés & Prix | ~60 | WFP/VAM, ANSD |
| Télédétection | ~65 | Sentinel-2, DE Africa |
| IA & MLOps | ~97 | Documentation SmartAgri |

---

## 5. Navigation et requêtes

### 5.1 Requête par parcelle

```
MATCH (c:Cell {id: 3456})
  -[:belongs_to]->(p:PowerCell)
  -[:measured_at]->(w:WeatherObs {date: today()})
MATCH (c)-[:has_soil]->(s:SoilType)
MATCH (c)-[:grows]->(crop:Crop)
RETURN c, p, w, s, crop
```

### 5.2 Propagation d'alertes

```
Cell anomalie détectée
  → Agent Monitoring évalue le risque
  → Si critique : Agent Irrigation recommande
  → SmartAgri Knowledge fournit le contexte
  → Assistant Parcellaire notifie l'agriculteur
```

---

## 6. Export et reconstruction

### 6.1 Format d'export

- **NetworkX** : graphe Python sérialisé (JSON/GraphML)
- **Neo4j** : import Cypher avec contraintes et index
- **CSV** : tables nœuds + relations pour import tabulaire

### 6.2 Reconstruction

1. Importer les 28 datasets (Data Lake).
2. Créer les nœuds statiques (régions, cellules, marchés, cultures).
3. Connecter les observations temporelles.
4. Attacher les 9 modèles IA et 4 agents.
5. Indexer les 527 chunks de connaissances.

---

*Document généré à partir des actifs SmartAgri92.*
*PAS Challenge 2026 — Équipe Agri-Moderne 5.0*
