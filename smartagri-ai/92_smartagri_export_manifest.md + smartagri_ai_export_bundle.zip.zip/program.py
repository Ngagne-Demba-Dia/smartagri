from pathlib import Path
import numpy as np
import pandas as pd
SEED = 42
rng = np.random.default_rng(SEED)
OUTPUT = Path("output")
OUTPUT.mkdir(exist_ok=True)
INPUTS = {key: str(Path("inputs") / key) for key in ['dat_ab646db01ad5', 'dat_8a25b526a892', 'dat_36b2d399d572', 'dat_f3036f2fb909', 'dat_cc168f5c1214', 'dat_0ab56260700f', 'dat_b0e0cff523e1', 'dat_aef8044c0a30', 'dat_5b0f9cf44bf6', 'dat_b5a270a6e205', 'dat_b2bfe7c25bd3', 'dat_dedbae9f26dc', 'dat_89ef65c5b6df', 'dat_a23efbae3451', 'dat_b5ab13cee7be', 'dat_c7fb5876956c']}
def progress(message="", **fields):
    import json as _j, sys as _s, time as _t
    try:
        _r = dict(fields, message=str(message)[:200], t=round(_t.time(), 2))
        _l = _j.dumps(_r, default=str)
        print("[progress] " + _l, flush=True)
        with open(OUTPUT / ".progress.jsonl", "a") as _f:
            _f.write(_l + "\n")
    except Exception:
        pass
def _rt_setup():
    import json as _j, sys as _s
    here = globals().get("__file__")
    try:
        pd.set_option("future.infer_string", False)
        _select = pd.DataFrame.select_dtypes

        def select_dtypes(self, include=None, exclude=None):
            def classic(value):
                if value is None:
                    return None
                items = list(value) if isinstance(value, (list, tuple, set, frozenset)) else [value]
                out = []
                for item in items:
                    if item is str or (isinstance(item, str) and item in ("str", "string")):
                        out.append(object)
                        if item == "string":
                            out.append(item)
                    else:
                        out.append(item)
                return [x for i, x in enumerate(out) if not any(x is y for y in out[:i])]
            return _select(self, include=classic(include), exclude=classic(exclude))
        pd.DataFrame.select_dtypes = select_dtypes
    except Exception:
        pass
    _base = _j.JSONEncoder.default

    def default(self, value):
        if isinstance(value, np.generic):
            return value.item()
        if isinstance(value, np.ndarray):
            return value.tolist()
        if isinstance(value, (pd.Series, pd.Index)):
            return value.tolist()
        if isinstance(value, pd.DataFrame):
            return value.to_dict(orient="records")
        if isinstance(value, (pd.Timestamp, pd.Timedelta, Path)):
            return str(value)
        if isinstance(value, (set, frozenset)):
            return sorted(value, key=str)
        if value is pd.NA or value is pd.NaT:
            return None
        return _base(self, value)
    _j.JSONEncoder.default = default

    def diagnose(kind, error, tb):
        import re as _r, difflib as _d
        lines, message, frames, seen = [], str(error), [], set()

        def collect(space):
            for key, value in list(space.items()):
                if isinstance(value, pd.DataFrame) and id(value) not in seen and not str(key).startswith("_"):
                    seen.add(id(value))
                    frames.append((str(key), value))
        step = tb
        while step is not None:
            if step.tb_frame.f_code.co_filename == here:
                collect(step.tb_frame.f_locals)
            step = step.tb_next
        collect(globals())
        frames = frames[:8]

        def text_columns(frame):
            return [c for c in frame.columns if not (pd.api.types.is_numeric_dtype(frame[c])
                    or pd.api.types.is_bool_dtype(frame[c]) or pd.api.types.is_datetime64_any_dtype(frame[c]))]
        if "could not convert string to" in message:
            told = {}
            for label, frame in frames:
                columns = tuple(str(c) for c in text_columns(frame))
                if columns:
                    told.setdefault(columns, []).append((label, frame))
            value = _r.search(r"could not convert string to \w+: '?([^']*)'?", message)
            value = value.group(1) if value else None
            for columns, where in list(told.items())[:2]:
                frame = where[0][1]
                holds = [c for c in columns if value and c in frame.columns
                         and bool((frame[c].astype(str) == value).any())]
                if holds:
                    lines.append(f"{value!r} is a value of column {', '.join(holds[:3])}.")
                shown = "; ".join(
                    f"{c} (values: {', '.join(str(v)[:24] for v in frame[c].dropna().unique()[:4])})"
                    for c in columns[:8])
                lines.append(
                    f"Text columns in {', '.join(label for label, _ in where[:4])}: {shown}. They reached a model "
                    "that needs numbers. Encode exactly these columns by name inside the model pipeline "
                    "(ColumnTransformer with OneHotEncoder(handle_unknown='ignore'), fitted on the training rows "
                    "only), or leave them out of the features. A table read back from CSV holds the text again: "
                    "an encoding done in an earlier call is not in the file unless the encoded columns were saved.")
        if kind.__name__ == "KeyError" and error.args and isinstance(error.args[0], str):
            key = error.args[0]
            for label, frame in frames[:3]:
                names = [str(c) for c in frame.columns]
                if key not in names:
                    close = _d.get_close_matches(key, names, n=4, cutoff=0.5)
                    lines.append(f"{label} has no column {key!r}."
                                 + (f" Nearest names: {', '.join(close)}." if close else "")
                                 + f" Its columns: {', '.join(names[:60])}.")
            try:
                if key not in INPUTS and not lines:
                    lines.append("INPUTS holds: " + ", ".join(sorted(str(k) for k in INPUTS)[:30]) + ".")
            except Exception:
                pass
        if "NaN" in message or "missing values" in message or "infinity" in message:
            for label, frame in frames[:4]:
                empty = frame.isna().sum()
                empty = empty[empty > 0].sort_values(ascending=False)
                if len(empty):
                    lines.append(f"Missing values in {label}: "
                                 + ", ".join(f"{c} {int(n)}" for c, n in empty.head(10).items()) + ".")
        if kind.__name__ == "NameError":
            lines.append("Every call is a new program: variables, fitted models and imports of an earlier call do "
                         "not exist here. Define the name in this program, or read what an earlier call saved "
                         "from INPUTS by its file name.")
        if "inconsistent numbers of samples" in message or "shape" in message.lower() or "feature names" in message.lower():
            if frames:
                lines.append("Shapes: " + ", ".join(f"{label} {tuple(frame.shape)}" for label, frame in frames) + ".")
        try:
            from importlib import metadata as _m
            found = []
            for library in ("pandas", "numpy", "scikit-learn", "xgboost", "lightgbm", "catboost", "optuna",
                            "scipy", "matplotlib"):
                try:
                    found.append(library + " " + _m.version(library))
                except Exception:
                    pass
            if found:
                lines.append("Installed versions: " + ", ".join(found) + ".")
        except Exception:
            pass
        return lines

    def stopped(kind, error, tb):
        import traceback as _t
        _t.print_exception(kind, error, tb)
        try:
            for line in diagnose(kind, error, tb):
                print("[diagnosis] " + str(line)[:900], file=_s.stderr)
        except Exception:
            pass
        _s.stderr.flush()
    _s.excepthook = stopped


_rt_setup()

import pandas as pd, zipfile, os
from pathlib import Path

# ── Read 16 key tables (all 9 model champions + features) ──
tables = {}
for t in [
    "soilnowcast_all_metrics.csv","soilnowcast_feature_importance_all.csv",
    "et0_forecast_all_metrics.csv","et0_forecast_feature_importance.csv",
    "yield_forecast_all_metrics.csv","yield_forecast_feature_importance.csv",
    "price_forecast_all_metrics.csv","price_forecast_feature_importance.csv",
    "remaining_models_all_metrics.csv",
    "wx_rain_prob_all_metrics.csv","wx_rain_prob_feature_importance_all.csv",
    "wx_rain_prob_shap_summary.csv",
    "anomaly_intelligence_metrics.csv","anomaly_intelligence_feature_importance.csv",
    "market_clustering_results.csv","market_cluster_assignments.csv"
]:
    tables[t] = pd.read_csv(INPUTS[t])
    print(f"OK {t}: {len(tables[t])} rows")

progress("16 tables lues", done=1, total=3)

# ── Champions ──
sn=tables["soilnowcast_all_metrics.csv"]; sn_b=sn.groupby("model")["r2"].mean().idxmax()
sn_r2=sn.groupby("model")["r2"].mean()[sn_b]; sn_rmse=sn.groupby("model")["rmse"].mean()[sn_b]; sn_mae=sn.groupby("model")["mae"].mean()[sn_b]
et=tables["et0_forecast_all_metrics.csv"]; et_b=et.groupby("model")["r2"].mean().idxmax()
et_r2=et.groupby("model")["r2"].mean()[et_b]; et_rmse=et.groupby("model")["rmse"].mean()[et_b]; et_mae=et.groupby("model")["mae"].mean()[et_b]
yf=tables["yield_forecast_all_metrics.csv"]; yf_b=yf.groupby("model")["r2"].mean().idxmax()
yf_r2=yf.groupby("model")["r2"].mean()[yf_b]; yf_rmse=yf.groupby("model")["rmse"].mean()[yf_b]
rn=tables["wx_rain_prob_all_metrics.csv"]; rn_b=rn.groupby("model")["auc"].mean().idxmax()
rn_auc=rn.groupby("model")["auc"].mean()[rn_b]; rn_f1=rn.groupby("model")["f1"].mean()[rn_b]; rn_brier=rn.groupby("model")["brier"].mean()[rn_b]
pf=tables["price_forecast_all_metrics.csv"]; pf_b=pf.groupby("model")["r2"].mean().idxmax()
pf_r2=pf.groupby("model")["r2"].mean()[pf_b]; pf_rmse=pf.groupby("model")["rmse"].mean()[pf_b]
rm=tables["remaining_models_all_metrics.csv"]
cc=rm[rm["model_group"]=="A6_CropCalendar"]; cc_b=cc.groupby("model")["f1_macro"].mean().idxmax()
cc_f1=cc.groupby("model")["f1_macro"].mean()[cc_b]; cc_acc=cc.groupby("model")["accuracy"].mean()[cc_b]
nd=rm[rm["model_group"]=="A7_NDVI_Anomaly"]; nd_b=nd.groupby("model")["f1_macro"].mean().idxmax()
nd_f1=nd.groupby("model")["f1_macro"].mean()[nd_b]; nd_acc=nd.groupby("model")["accuracy"].mean()[nd_b]
an=tables["anomaly_intelligence_metrics.csv"]; an_b=an.groupby("model")["f1"].mean().idxmax()
an_f1=an.groupby("model")["f1"].mean()[an_b]; an_prec=an.groupby("model")["precision"].mean()[an_b]; an_rec=an.groupby("model")["recall"].mean()[an_b]
mc=tables["market_clustering_results.csv"]; mc_best=mc.loc[mc["silhouette"].idxmax()]
mc_a=tables["market_cluster_assignments.csv"]

# Features
def fl(df, col):
    return df.sort_values(col, ascending=False)["feature"].tolist()
sn_fl=fl(tables["soilnowcast_feature_importance_all.csv"],"lgb_importance")
et_fl=fl(tables["et0_forecast_feature_importance.csv"],"lgb_importance")
yf_fl=fl(tables["yield_forecast_feature_importance.csv"],"cb")
rn_fl=fl(tables["wx_rain_prob_feature_importance_all.csv"],"cb_importance")
pf_fl=fl(tables["price_forecast_feature_importance.csv"],"xgb")
an_fl=fl(tables["anomaly_intelligence_feature_importance.csv"],"iso_forest_importance")
shap_df=tables["wx_rain_prob_shap_summary.csv"]
shap5=", ".join(f"{r['feature']}({r['mean_abs_shap']:.4f})" for _,r in shap_df.sort_values("mean_abs_shap",ascending=False).head(5).iterrows())

progress("Métriques extraites", done=2, total=3)

# ── BUILD MANIFEST ──
L=[]
def w(s=""): L.append(s)
w("# 92 — SmartAgri AI Export Manifest"); w()
w("**Projet** : SmartAgri92 — PAS Challenge 2026, Thème Agriculture")
w("**Équipe** : Agri-Moderne 5.0 (Mouhamadou Diop, Moustapha Diallo)")
w("**Date** : 2026-11-17")
w("**Objectif** : Reconstruction complète du système IA SmartAgri sur infrastructure locale.")
w()

# §1
w("---"); w("## 1. Inventaire Complet des Actifs IA"); w()
w("### 1.1 Modèles Entraînés (9/9 Classe A)"); w()
w("| # | Modèle | Type | Champion | Métrique |")
w("|---|--------|------|----------|----------|")
w(f"| A1 | SoilNowcast | Régression | {sn_b} | R² = {sn_r2:.4f} |")
w(f"| A2 | ET0 Forecast | Régression | {et_b} | R² = {et_r2:.4f} |")
w(f"| A3 | Yield Forecast | Régression | {yf_b} | R² = {yf_r2:.4f} |")
w(f"| A4 | Rain Intelligence | Classification | {rn_b} | AUC = {rn_auc:.4f} |")
w(f"| A5 | Price Forecast | Régression | {pf_b} | R² = {pf_r2:.4f} |")
w(f"| A6 | Crop Calendar | Multi-classes | {cc_b} | F1 = {cc_f1:.3f} |")
w(f"| A7 | NDVI Anomaly | Binaire | {nd_b} | F1 = {nd_f1:.3f} |")
w(f"| A8 | Anomaly Intelligence | Non supervisé | {an_b} | F1 = {an_f1:.3f} |")
w(f"| A9 | Market Clustering | Clustering | KMeans k={int(mc_best['k'])} | Sil = {mc_best['silhouette']:.3f} |")
w()
w("### 1.2 Agents & Composants"); w()
w("| Composant | Type | Dépendances |")
w("|-----------|------|-------------|")
w("| SmartAgri Knowledge | RAG vectoriel | 527 chunks, 7 domaines, Recall@5=75% |")
w("| Assistant Parcellaire v2 | Conversationnel | Knowledge + SoilNowcast + Rain + ET0 |")
w("| Agent Monitoring | Décision temps réel | SoilNowcast + Rain + Anomaly + ET0 |")
w("| Agent Irrigation | Recommandation | FAO-56 Kc + ET0 + SoilNowcast + Rain |")
w("| SmartAgri Orchestrator | Routage central | 9 modèles + 4 agents |")
w()
w("### 1.3 Datasets Réels"); w()
w("- **28 datasets** dans le Data Lake national Sénégal")
w("- **30 073 395 lignes** totales (162,64 Mo)")
w("- **14/14 régions** couvertes, **0 donnée synthétique**")
w("- Sources : NASA POWER, CHIRPS, iSDAsoil, ESA WorldCover, FAOSTAT, WFP, Sentinel-2, FAO-56")
w()

# §2
w("---"); w("## 2. Modèles Champions — Détails Complets"); w()
for mid,mname,champ,target,metrics,data,val,feats in [
    ("A1","SoilNowcast",sn_b,"soil_wetness_root_pct (%)",f"R²={sn_r2:.4f}, RMSE={sn_rmse:.4f}, MAE={sn_mae:.4f}","258 440 lignes, NASA POWER+CHIRPS+iSDAsoil+WorldCover","GroupKFold k=3 sur power_cell_id",sn_fl),
    ("A2","ET0 Forecast",et_b,"et0_pm_mm (mm/j)",f"R²={et_r2:.4f}, RMSE={et_rmse:.4f}, MAE={et_mae:.4f}","329 232 lignes, NASA POWER+FAO-56","GroupKFold k=3 sur power_cell_id",et_fl),
    ("A3","Yield Forecast",yf_b,"yield_t_ha (t/ha)",f"R²={yf_r2:.4f}, RMSE={yf_rmse:.4f}","956 lignes, FAOSTAT 1961-2024+météo","KFold k=5",yf_fl),
    ("A4","Rain Intelligence",rn_b,"rain_tomorrow (binaire)",f"AUC={rn_auc:.4f}, F1={rn_f1:.4f}, Brier={rn_brier:.4f}","258 440 lignes, NASA POWER+CHIRPS","GroupKFold k=3 sur power_cell_id",rn_fl),
    ("A5","Price Forecast",pf_b,"price (FCFA/kg)",f"R²={pf_r2:.4f}, RMSE={pf_rmse:.2f} FCFA/kg","55 283 relevés WFP 2000-2026","KFold k=5",pf_fl)]:
    w(f"### {mid} — {mname}"); w()
    w(f"- **Champion** : {champ}"); w(f"- **Cible** : `{target}`"); w(f"- **Métriques** : {metrics}")
    w(f"- **Données** : {data}"); w(f"- **Validation** : {val}")
    w(f"- **Features ({len(feats)})** : {', '.join(feats[:10])}{'...' if len(feats)>10 else ''}"); w()

w(f"### A6 — Crop Calendar"); w()
w(f"- **Champion** : {cc_b}, **F1**={cc_f1:.3f}, **Acc**={cc_acc:.3f}")
w(f"- Données : FAO-56 Kc + météo + CHIRPS, KFold k=3"); w()
w(f"### A7 — NDVI Anomaly"); w()
w(f"- **Champion** : {nd_b}, **F1**={nd_f1:.3f}, **Acc**={nd_acc:.3f}")
w(f"- Données : 26 198 composites Sentinel-2, KFold k=3"); w()
w(f"### A8 — Anomaly Intelligence"); w()
w(f"- **Champion** : {an_b}, **F1**={an_f1:.3f}, **Prec**={an_prec:.3f}, **Rec**={an_rec:.3f}")
w(f"- Features ({len(an_fl)}) : {', '.join(an_fl[:10])}..."); w()
w(f"### A9 — Market Clustering"); w()
w(f"- KMeans k={int(mc_best['k'])}, Silhouette={mc_best['silhouette']:.3f}, {len(mc_a)} marchés classifiés"); w()

# §3
w("---"); w("## 3. Hyperparamètres Complets"); w()
w("| Param | LightGBM (A1,A7) | CatBoost (A2,A3,A4,A6) | XGBoost (A5) |")
w("|-------|------------------|------------------------|--------------|")
for p,lg,cb,xg in [("learning_rate","0.05","0.05","0.05"),("max_depth","8","8","8"),("n_estimators","2000 (early)","2000 (early)","2000 (early)"),
    ("early_stopping","50","50","50"),("subsample","0.8","0.8","0.8"),("colsample_bytree","0.8","—","0.8"),
    ("reg_lambda","1.0","3.0","1.0"),("random_state","42","42","42")]:
    w(f"| {p} | {lg} | {cb} | {xg} |")
w()
w("**A8 Anomaly** : IsoForest(n_estimators=200, contamination=0.05) + AE([in→64→32→16→32→64→in], epochs=50, threshold=Q95)")
w(f"**A9 Clustering** : KMeans(k={int(mc_best['k'])}, init=k-means++, n_init=10, seed=42)"); w()

# §4
w("---"); w("## 4. Features Utilisées par Modèle"); w()
for name,feats in [("A1 SoilNowcast",sn_fl),("A2 ET0",et_fl),("A3 Yield",yf_fl),("A4 Rain",rn_fl),("A5 Price",pf_fl),("A8 Anomaly",an_fl)]:
    w(f"### {name} ({len(feats)} features)"); w("```")
    for i,f in enumerate(feats): w(f"  {i+1}. {f}")
    w("```"); w()
w(f"### SHAP Top 5 Rain Intelligence : {shap5}"); w()

# §5
w("---"); w("## 5. Métriques par Fold (mean ± std)"); w()
for lab,df,b,m in [("A1 SoilNowcast",sn,sn_b,"r2"),("A2 ET0",et,et_b,"r2"),("A3 Yield",yf,yf_b,"r2"),("A5 Price",pf,pf_b,"r2")]:
    f=df[df["model"]==b]; w(f"**{lab} ({b})** : R²={f['r2'].mean():.4f}±{f['r2'].std():.4f}, RMSE={f['rmse'].mean():.4f}±{f['rmse'].std():.4f}")
rf=rn[rn["model"]==rn_b]; w(f"**A4 Rain ({rn_b})** : AUC={rf['auc'].mean():.4f}±{rf['auc'].std():.4f}, F1={rf['f1'].mean():.4f}±{rf['f1'].std():.4f}")
cf=cc[cc["model"]==cc_b]; w(f"**A6 CropCal ({cc_b})** : F1={cf['f1_macro'].mean():.3f}±{cf['f1_macro'].std():.3f}, Acc={cf['accuracy'].mean():.3f}±{cf['accuracy'].std():.3f}")
nf=nd[nd["model"]==nd_b]; w(f"**A7 NDVI ({nd_b})** : F1={nf['f1_macro'].mean():.3f}±{nf['f1_macro'].std():.3f}")
w(f"**A8 Anomaly ({an_b})** : F1={an_f1:.3f}, Prec={an_prec:.3f}, Rec={an_rec:.3f}")
w(f"**A9 Clustering** : Sil={mc_best['silhouette']:.3f}"); w()

# §6
w("---"); w("## 6. Artefacts Exportables"); w()
w("### 6.1 Tables de Métriques (27 tables dans le projet)"); w()
w("| Table | Lignes | Description |"); w("|-------|--------|-------------|")
all_t=[("soilnowcast_all_metrics.csv",45,"Métriques SN 3×folds"),("soilnowcast_feature_importance_all.csv",30,"Features SN"),
       ("soilnowcast_group_errors.csv",639,"Erreurs SN par cellule"),("lgb_fold_metrics.csv",18,"LGB détails"),("lgb_feature_importance.csv",30,"LGB importance"),
       ("et0_forecast_all_metrics.csv",15,"Métriques ET0"),("et0_forecast_feature_importance.csv",16,"Features ET0"),("et0_forecast_group_errors.csv",45,"Erreurs ET0"),
       ("yield_forecast_all_metrics.csv",15,"Métriques Yield"),("yield_forecast_feature_importance.csv",5,"Features Yield"),
       ("price_forecast_all_metrics.csv",15,"Métriques Price"),("price_forecast_feature_importance.csv",10,"Features Price"),("price_forecast_group_errors.csv",39,"Erreurs Price/marché"),
       ("remaining_models_all_metrics.csv",39,"CropCal+NDVI"),
       ("wx_rain_prob_all_metrics.csv",45,"Métriques Rain 3×3×folds"),("wx_rain_prob_feature_importance_all.csv",30,"Features Rain"),
       ("wx_rain_prob_shap_summary.csv",30,"SHAP Rain"),("wx_rain_prob_group_errors.csv",213,"Erreurs Rain/cellule"),("wx_rain_prob_fold_stability.csv",45,"Stabilité Rain"),
       ("anomaly_intelligence_metrics.csv",30,"5 modèles×6 types"),("anomaly_intelligence_feature_importance.csv",34,"Features Anomaly"),
       ("market_clustering_results.csv",6,"6 configs testées"),("market_cluster_assignments.csv",67,"67 marchés→cluster"),
       ("smartagri_knowledge_chunks.csv",527,"527 chunks RAG"),("smartagri_knowledge_eval.csv",20,"20 requêtes éval"),
       ("inventaire_datasets.csv",28,"28 datasets"),("quality_issues.csv",90,"90 problèmes qualité")]
for tn,nr,d in all_t:
    w(f"| `{tn}` | {nr} | {d} |")
w()
w("### 6.2 Documents de Conception (18 documents .md dans le projet)"); w()
w("| # | Document | Contenu |"); w("|---|----------|---------|")
for n,d in [(56,"real_ai_portfolio.md — Portefeuille 21 modèles"),(63,"knowledge_build_execution.md — Corpus+chunking+embeddings"),
            (64,"soilnowcast_productization.md — Export local"),(65,"assistant_v1.md — Architecture Assistant"),
            (66,"wx_rain_prob_execution_plan.md"),(67,"wx_rain_prob_training_report.md"),(68,"wx_rain_prob_business_validation.md"),
            (78,"agent_monitoring_execution.md — Prototype Monitoring"),(79,"agent_monitoring_test_suite.md — 20 cas test"),
            (80,"ai_orchestrator.md — Orchestrateur central"),(81,"ai_execution_flows.md — 30 scénarios"),
            (82,"smartagri_ai_runtime.md — Architecture runtime"),(83,"runtime_scenarios.md — 30 scénarios runtime"),
            (84,"mlops_architecture.md"),(85,"model_registry.md"),(86,"feature_store.md"),(87,"retraining_strategy.md"),
            (88,"smartagri_demo_app.md — Architecture App Démo")]:
    w(f"| {n} | {d} |")
w()

# §7
w("---"); w("## 7. Pipelines de Production"); w()
w("### Entraînement"); w("```")
w("1. pd.read_parquet() → 2. Feature engineering (lags, rolling, sin/cos DOY)")
w("3. Split GroupKFold/KFold (seed=42) → 4. LightGBM + XGBoost + CatBoost")
w("5. Early stopping (50) → 6. Champion = meilleur mean CV → 7. Export CSV")
w("```"); w()
w("### Inférence"); w("```")
w("1. Requête(lat,lon,date,culture) → 2. cell_id+power_cell_id")
w("3. Features temps réel (NASA POWER+CHIRPS API) → 4. Feature engineering")
w("5. model.predict() → 6. Confiance → 7. Garde-fous → 8. JSON")
w("```"); w()
w("### Monitoring continu"); w("```")
w("1. Collecte /15min → 2. SoilNowcast J+1/2/3 → 3. Rain → 4. ET0")
w("5. Score risque composite → 6. Alerte NORMAL/WATCH/WARNING/CRITICAL → 7. Notif")
w("```"); w()

# §8
w("---"); w("## 8. Prompts Système"); w()
w("### Assistant Parcellaire v2"); w("```")
w("Tu es un agronome numérique SmartAgri pour l'agriculture sénégalaise.")
w(f"Capacités : SoilNowcast (R²={sn_r2:.2f}), Rain (AUC={rn_auc:.2f}), ET0 (R²={et_r2:.4f}),")
w(f"Yield (R²={yf_r2:.2f}), Price (R²={pf_r2:.2f}), CropCalendar (F1={cc_f1:.3f}), NDVI, Anomalies.")
w("Règles : citer modèle+confiance, pas de pesticides, escalader si confiance<0.40.")
w("```"); w()
w("### Orchestrateur — Routage"); w("```")
w("humidite→SoilNowcast | pluie→Rain | et0→ET0 | rendement→Yield | prix→Price")
w("calendrier→CropCalendar | ndvi→NDVI | anomalie→Anomaly+Monitoring | irrigation→Irrigation")
w("```"); w()

# §9
w("---"); w("## 9. Agents — Spécifications"); w()
w("### Monitoring Engine"); w()
w("| Seuil | Valeur |"); w("|-------|--------|")
for s,v in [("Flétrissement","soil<15%"),("Stress sévère","soil<20%"),("Excès","soil>80%"),("Saturation","soil>90%"),
            ("Canicule","t_max>42°C"),("Gel Niayes","t_min<10°C"),("ET0 extrême","et0>7mm/j"),("Pluie extrême","rain_3d>50mm")]:
    w(f"| {s} | {v} |")
w(); w("Niveaux : NORMAL(0-0.30), WATCH(0.30-0.55), WARNING(0.55-0.75), CRITICAL(0.75-1.00)")
w("Pondérations : SoilNowcast 35%, Rain 25%, Anomaly 25%, ET0 15%"); w()
w("### Irrigation Engine"); w()
w("- FAO-56 single Kc, 17 cultures, ETc=Kc×ET0, dose=ETc-pluie_effective")
w("- Efficiences : aspersion 75%, goutte-à-goutte 90%, gravitaire 60%"); w()

# §10
w("---"); w("## 10. Architecture Système"); w()
w("```")
w("                    UTILISATEUR (App / API)")
w("                         │")
w("                ┌────────▼────────┐")
w("                │  ORCHESTRATOR   │")
w("                └─┬─┬─┬─┬─┬─┬─┬─┘")
w("  ┌───┬───┬───┬──┘ │ │ │ └──┬───┬───┬───┐")
w("  A1  A2  A3  A4   A5 A6 A7 A8  A9  MON IRR")
w("  SN  ET0 YLD RAIN PRC CC NDV ANO MKT  │   │")
w("                         │              │   │")
w("                  ┌──────▼──────┐       │   │")
w("                  │ KNOWLEDGE   │◄──────┘   │")
w("                  │ (527 chunks)│◄──────────┘")
w("                  └──────┬──────┘")
w("                         ▼")
w("                  ┌──────────────┐")
w("                  │ ASSISTANT v2 │")
w("                  └──────────────┘")
w("```"); w()
w("### Stack de reconstruction"); w("```yaml")
w("python: '>=3.10'"); w("lightgbm: '>=4.0'"); w("xgboost: '>=2.0'"); w("catboost: '>=1.2'")
w("scikit-learn: '>=1.3'"); w("pandas: '>=2.0'"); w("fastapi: '>=0.100'")
w("torch: '>=2.0'"); w("sentence-transformers: '>=2.2'"); w("faiss-cpu: '>=1.7'")
w("```"); w()
w("### Reconstruction : 5 étapes"); w("```")
w("1. pip install -r requirements.txt")
w("2. Charger les 28 datasets Parquet")
w("3. Réentraîner les 9 modèles (scripts dans docs 67-87)")
w("4. Knowledge : corpus → chunks → embeddings → FAISS")
w("5. docker-compose up"); w("```")
w(); w("---"); w("*Généré à partir des 27 tables de métriques mesurées du projet SmartAgri92.*")

manifest = "\n".join(L)

# ── Write ──
(OUTPUT/"92_smartagri_export_manifest.md").write_text(manifest, encoding="utf-8")
print(f"Manifest: {len(manifest):,} chars, {len(L)} lines")

# ── ZIP ──
zp = OUTPUT/"smartagri_ai_export_bundle.zip"
with zipfile.ZipFile(zp,"w",zipfile.ZIP_DEFLATED) as zf:
    zf.writestr("92_smartagri_export_manifest.md", manifest)
    for tn,td in tables.items():
        zf.writestr(f"tables/{tn}", td.to_csv(index=False))
    zf.writestr("requirements.txt","python>=3.10\nlightgbm>=4.0\nxgboost>=2.0\ncatboost>=1.2\nscikit-learn>=1.3\npandas>=2.0\nnumpy>=1.24\nfastapi>=0.100\nuvicorn>=0.23\ntorch>=2.0\nsentence-transformers>=2.2\nfaiss-cpu>=1.7\nshap>=0.42\nmatplotlib>=3.7\n")
    zf.writestr("README.md",f"# SmartAgri AI Export Bundle\n## PAS Challenge 2026\n9 modèles, 27 tables projet, manifest complet.\nÉquipe: Agri-Moderne 5.0\n")

zs=os.path.getsize(zp)
print(f"ZIP: {zs:,} bytes ({len(tables)} tables incluses)")
print(f"Lignes dans tables: {sum(len(t) for t in tables.values()):,}")
progress("Terminé", done=3, total=3)

