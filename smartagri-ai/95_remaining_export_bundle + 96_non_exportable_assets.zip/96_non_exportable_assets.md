# 96_non_exportable_assets.md
# SmartAgri92 - Actifs non exportables

## Resume

| Categorie | Recupere | Non exportable | A reconstruire |
|-----------|----------|----------------|----------------|
| Documents md (56-95) | 30+ | 0 | 0 |
| Tables metriques (27) | 27/27 | 0 | 0 |
| Modeles LightGBM | 15/15 | 0 | 0 |
| Modeles XGB/CB/KMeans | archives | 0 | 0 |
| Data Lake (28 datasets) | 28/28 | 0 | 0 |
| App Demo source | 19 fichiers | 0 | 0 |
| Configurations | 5+ | 0 | 0 |
| SHAP exports | 3/3 | 0 | 0 |
| Knowledge chunks | 527 | 0 | 0 |

---

## Elements NON EXPORTABLES

### 1. Runtime OctOpus (octopus.ask, octopus.db.query)
- Nom : Connexion octopus.ask / octopus.db.query
- Raison : API native OctOpus, non serialisable
- Emplacement : Runtime de l app SmartAgri92
- Solution : Remplacer par FastAPI local avec :
  - Moteur RAG (LangChain + ChromaDB) pour octopus.ask
  - Backend SQLite/PostgreSQL pour octopus.db.query
  - Les 527 chunks sont exportes dans smartagri_knowledge_chunks.csv

### 2. App SmartAgri92 hebergee
- Nom : Application web hebergee SmartAgri92
- Raison : Hebergement natif OctOpus, non transferable
- Emplacement : octopus.ml/a/new-app-771f89
- Solution : Code source React exporte (19 fichiers, 107 Ko).
  Reconstruire avec : npx create-vite smartagri92 --template react-ts
  Dependances : react-router-dom, framer-motion, recharts, lucide-react,
  radix-ui/react-slider, tailwindcss, shadcn/ui

### 3. Index vectoriel SmartAgri Knowledge
- Nom : Index vectoriel Knowledge
- Raison : Index natif OctOpus, non serialisable
- Emplacement : Backend OctOpus (set_up_app_assistant)
- Solution : 527 chunks exportes en CSV. Reconstruire avec ChromaDB ou FAISS.

### 4. Collections octopus.db
- Nom : 13 collections de donnees app
- Raison : Base de donnees app native OctOpus
- Emplacement : Collections octopus.db
- Solution : Toutes les 27 tables CSV sont exportees. Charger dans SQLite.

### 5. Historique de conversation
- Nom : 164+ tours de conversation
- Raison : Donnees de session OctOpus, non serialisable
- Emplacement : Projet OctOpus (chat history)
- Solution : Non critique. Decisions documentees dans les md 56-95.

### 6. ZIP execution SoilNowcast (58 Mo)
- Nom : SoilNowcast - LightGBM fix output.zip
- Raison : Trop volumineux (58 Mo), logs intermediaires
- Emplacement : Fichiers du projet OctOpus
- Solution : Telechargeable individuellement. Non critique si lgb_models_native.zip recupere.

---

## BILAN DEFINITIF

### Recupere (5 ZIPs = reconstruction complete)
| ZIP | Taille | Contenu |
|-----|--------|---------|
| smartagri_complete_ai_bundle.zip | 281 Ko | 58 fichiers : docs, metriques, modeles legers |
| smartagri_complementary_bundle.zip | 138 Ko | 18 fichiers : tables complementaires |
| lgb_models_native.zip | 54 Mo | 15 modeles LightGBM SoilNowcast |
| octopus_import_bundle.zip | 39 Mo | Data Lake 28 datasets (30M lignes) |
| 95_remaining_export_bundle.zip | nouveau | App source + doc manquant |

### Jamais recuperable
- Runtime octopus.ask (remplacable par FastAPI + ChromaDB)
- Hebergement app (remplacable par Vite + Vercel/Netlify)
- Index vectoriel (reconstructible depuis les chunks CSV)

### A reconstruire localement
1. Backend API (FastAPI) pour remplacer octopus.ask avec ChromaDB + embedding
2. Backend DB (SQLite) pour remplacer octopus.db.query avec les 27 CSV
3. Hebergement React (Vite + Vercel) pour remplacer octopus.ml
4. Re-indexer les 527 chunks dans un moteur vectoriel

Estimation de reconstruction : 2-3 jours pour un developpeur fullstack.
