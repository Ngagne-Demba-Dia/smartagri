import { BrowserRouter, Routes, Route, Navigate } from "react-router-dom";
import Sidebar from "@/components/Sidebar";
import Dashboard from "@/pages/Dashboard";
import SoilNowcast from "@/pages/SoilNowcast";
import RainIntelligence from "@/pages/RainIntelligence";
import KnowledgeExplorer from "@/pages/KnowledgeExplorer";
import AssistantIA from "@/pages/AssistantIA";
import Monitoring from "@/pages/Monitoring";
import Irrigation from "@/pages/Irrigation";
import ScenarioSimulator from "@/pages/ScenarioSimulator";
import CarteSenegal from "@/pages/CarteSenegal";
import ImpactMetriques from "@/pages/ImpactMetriques";
import JuryDemo from "@/components/JuryDemo";
import TopBar from "@/components/TopBar";
import { useState } from "react";
export default function App() {
  const [demoOpen, setDemoOpen] = useState(false);
  return (
    <BrowserRouter>
      <div className="flex min-h-screen bg-[#0f172a]">
        <Sidebar />
        <main className="flex-1 min-w-0 overflow-y-auto flex flex-col">
          <TopBar onDemo={() => setDemoOpen(true)} />
          <div className="flex-1">
            <Routes>
              <Route path="/" element={<Dashboard />} />
              <Route path="/soilnowcast" element={<SoilNowcast />} />
              <Route path="/rain" element={<RainIntelligence />} />
              <Route path="/knowledge" element={<KnowledgeExplorer />} />
              <Route path="/assistant" element={<AssistantIA />} />
              <Route path="/monitoring" element={<Monitoring />} />
              <Route path="/irrigation" element={<Irrigation />} />
              <Route path="/simulator" element={<ScenarioSimulator />} />
              <Route path="/carte" element={<CarteSenegal />} />
              <Route path="/impact" element={<ImpactMetriques />} />
              <Route path="*" element={<Navigate to="/" replace />} />
            </Routes>
          </div>
          <footer className="border-t border-white/5 py-4 px-6 text-center text-sm text-slate-500">
            Propulse par OctOpus - Donnees 100 pct reelles - SmartAgri92
          </footer>
        </main>
      </div>
      {demoOpen && <JuryDemo onClose={() => setDemoOpen(false)} />}
    </BrowserRouter>
  );
}
