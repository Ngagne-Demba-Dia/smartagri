import { Button } from "@/components/ui/button";
export default function TopBar({ onDemo }: { onDemo: () => void }) {
  return (
    <div className="flex items-center justify-between px-6 py-3 border-b border-white/5">
      <span className="text-xs px-2 py-1 rounded-full bg-emerald-500/15 text-emerald-400 font-semibold border border-emerald-500/20">PAS Challenge 2026 - Agri-Moderne 5.0</span>
      <Button onClick={onDemo} className="glow-green-pulse bg-emerald-600 hover:bg-emerald-700 text-white text-sm font-semibold px-4">Demo Jury</Button>
    </div>
  );
}