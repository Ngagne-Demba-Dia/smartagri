import { Trophy } from "lucide-react";
export default function ChampionBadge({ algo, metric, value }: { algo: string; metric: string; value: string }) {
  return (
    <span className="inline-flex items-center gap-1.5 px-3 py-1 rounded-full bg-emerald-500/15 border border-emerald-500/30 text-emerald-400 text-xs font-semibold">
      <Trophy className="w-3.5 h-3.5" /> Champion: {algo} - {metric}={value}
    </span>
  );
}