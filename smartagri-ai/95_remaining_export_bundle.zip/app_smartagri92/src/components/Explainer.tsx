import { useState, type ReactNode } from "react";
import { ChevronDown, Lightbulb } from "lucide-react";
import { motion, AnimatePresence } from "framer-motion";
export default function Explainer({ title, children }: { title: string; children: ReactNode }) {
  const [open, setOpen] = useState(false);
  return (
    <div className="mt-8 glass-card rounded-xl overflow-hidden">
      <button onClick={() => setOpen(!open)} className="w-full flex items-center gap-3 px-5 py-4">
        <Lightbulb className="w-4 h-4 text-amber-400" />
        <span className="text-sm font-medium text-slate-300">Comment ca marche - {title}</span>
        <ChevronDown className={`w-4 h-4 ml-auto ${open ? "rotate-180" : ""}`} />
      </button>
      <AnimatePresence>
        {open && (
          <motion.div initial={{ height: 0 }} animate={{ height: "auto" }} exit={{ height: 0 }} className="overflow-hidden">
            <div className="px-5 pb-5 text-sm text-slate-400 space-y-2">{children}</div>
          </motion.div>
        )}
      </AnimatePresence>
    </div>
  );
}