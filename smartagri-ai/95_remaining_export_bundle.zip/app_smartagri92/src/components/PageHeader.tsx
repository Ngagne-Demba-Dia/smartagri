import type { ReactNode } from "react";
export default function PageHeader({ title, description, badge }: { title: string; description: string; badge?: ReactNode }) {
  return (
    <div className="mb-6">
      <h1 className="text-2xl font-bold text-white mb-1">{title}</h1>
      <p className="text-slate-400 text-sm">{description}</p>
      {badge && <div className="mt-2">{badge}</div>}
    </div>
  );
}