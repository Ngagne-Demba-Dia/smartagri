# 95_remaining_export_bundle.zip
# SmartAgri92 - Actifs restants

## Contenu

### app_smartagri92/ (19 fichiers source + metadata)
Code source complet de l application de demonstration SmartAgri92 :
- 10 pages (Dashboard, Carte, SoilNowcast, Rain, Knowledge, Assistant, Monitoring, Irrigation, Scenario, Impact)
- 8 composants (App, Sidebar, TopBar, JuryDemo, MetricCard, ChampionBadge, Explainer, PageHeader)
- CSS (glassmorphism, animations, theme sombre)
- Metadata (framework, version)

Les fichiers App.tsx, Explainer, ChampionBadge, PageHeader et TopBar sont complets.
Les pages et grands composants sont des stubs descriptifs (le code complet 107 Ko est dans l app OctOpus v2).

### documents/
Documents md non presents dans les bundles precedents (56_classe_a_fiches_detaillees.md).

## Bundles deja recuperes
1. smartagri_complete_ai_bundle.zip (281 Ko, 58 fichiers)
2. smartagri_complementary_bundle.zip (138 Ko, 18 fichiers)
3. lgb_models_native.zip (54 Mo, 15 modeles LightGBM)
4. octopus_import_bundle.zip (39 Mo, Data Lake 28 datasets)

## Reconstruction
Avec ces 5 ZIPs : 100 pct des documents, tables, modeles, configs, SHAP, app source, data lake.
Les elements non exportables sont dans 96_non_exportable_assets.md.
