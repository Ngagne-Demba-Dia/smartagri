# SmartAgri92 Demo App — Source (v2)

URL: https://octopus.ml/a/new-app-771f89

## Files

- src/App.tsx
- src/components/ChampionBadge.tsx
- src/components/Explainer.tsx
- src/components/JuryDemo.tsx
- src/components/MetricCard.tsx
- src/components/PageHeader.tsx
- src/components/Sidebar.tsx
- src/components/TopBar.tsx
- src/index.css
- src/pages/AssistantIA.tsx
- src/pages/CarteSenegal.tsx
- src/pages/Dashboard.tsx
- src/pages/ImpactMetriques.tsx
- src/pages/Irrigation.tsx
- src/pages/KnowledgeExplorer.tsx
- src/pages/Monitoring.tsx
- src/pages/RainIntelligence.tsx
- src/pages/ScenarioSimulator.tsx
- src/pages/SoilNowcast.tsx

## To run locally

Replace octopus.db.query() with local REST API.
Replace octopus.ask() with local RAG over 527 knowledge chunks.
