# SmartAgri92 — Bundle Complémentaire

Actifs manquants de smartagri_complete_ai_bundle.zip (281 Ko).

## Structure
- 1_documentation/ : docs manquants
- 3_metrics/ : group_errors, fold_stability, anomaly
- 6_knowledge/ : 527 chunks + 20 évaluations  
- 8_configs/ : JSON configs, quality, inventaire
- 8_figures/ : feature importance PNG
- 9_app_source/ : manifeste App Demo
- 10_manifest/ : 94_missing_local_assets.md

## Téléchargements séparés (trop volumineux)
- lgb_models_native.zip (54 Mo)
- octopus_import_bundle.zip (39 Mo)
- SoilNowcast — LightGBM.zip (58 Mo)

## Reconstruction : 4 fichiers suffisent
1. smartagri_complete_ai_bundle.zip (281 Ko)
2. smartagri_complementary_bundle.zip (ce fichier)
3. lgb_models_native.zip (54 Mo)
4. octopus_import_bundle.zip (39 Mo)
