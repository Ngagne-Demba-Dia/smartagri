from pathlib import Path
import numpy as np
import pandas as pd
SEED = 42
rng = np.random.default_rng(SEED)
OUTPUT = Path("output")
OUTPUT.mkdir(exist_ok=True)
INPUTS = {key: str(Path("inputs") / key) for key in ['pf_3256be22cdc342beb8f105d7']}
def progress(message="", **fields):
    import json as _j, sys as _s, time as _t
    try:
        _r = dict(fields, message=str(message)[:200], t=round(_t.time(), 2))
        _l = _j.dumps(_r, default=str)
        print("[progress] " + _l, flush=True)
        with open(OUTPUT / ".progress.jsonl", "a") as _f:
            _f.write(_l + "\n")
    except Exception:
        pass
def _rt_setup():
    import json as _j, sys as _s
    here = globals().get("__file__")
    try:
        pd.set_option("future.infer_string", False)
        _select = pd.DataFrame.select_dtypes

        def select_dtypes(self, include=None, exclude=None):
            def classic(value):
                if value is None:
                    return None
                items = list(value) if isinstance(value, (list, tuple, set, frozenset)) else [value]
                out = []
                for item in items:
                    if item is str or (isinstance(item, str) and item in ("str", "string")):
                        out.append(object)
                        if item == "string":
                            out.append(item)
                    else:
                        out.append(item)
                return [x for i, x in enumerate(out) if not any(x is y for y in out[:i])]
            return _select(self, include=classic(include), exclude=classic(exclude))
        pd.DataFrame.select_dtypes = select_dtypes
    except Exception:
        pass
    _base = _j.JSONEncoder.default

    def default(self, value):
        if isinstance(value, np.generic):
            return value.item()
        if isinstance(value, np.ndarray):
            return value.tolist()
        if isinstance(value, (pd.Series, pd.Index)):
            return value.tolist()
        if isinstance(value, pd.DataFrame):
            return value.to_dict(orient="records")
        if isinstance(value, (pd.Timestamp, pd.Timedelta, Path)):
            return str(value)
        if isinstance(value, (set, frozenset)):
            return sorted(value, key=str)
        if value is pd.NA or value is pd.NaT:
            return None
        return _base(self, value)
    _j.JSONEncoder.default = default

    def diagnose(kind, error, tb):
        import re as _r, difflib as _d
        lines, message, frames, seen = [], str(error), [], set()

        def collect(space):
            for key, value in list(space.items()):
                if isinstance(value, pd.DataFrame) and id(value) not in seen and not str(key).startswith("_"):
                    seen.add(id(value))
                    frames.append((str(key), value))
        step = tb
        while step is not None:
            if step.tb_frame.f_code.co_filename == here:
                collect(step.tb_frame.f_locals)
            step = step.tb_next
        collect(globals())
        frames = frames[:8]

        def text_columns(frame):
            return [c for c in frame.columns if not (pd.api.types.is_numeric_dtype(frame[c])
                    or pd.api.types.is_bool_dtype(frame[c]) or pd.api.types.is_datetime64_any_dtype(frame[c]))]
        if "could not convert string to" in message:
            told = {}
            for label, frame in frames:
                columns = tuple(str(c) for c in text_columns(frame))
                if columns:
                    told.setdefault(columns, []).append((label, frame))
            value = _r.search(r"could not convert string to \w+: '?([^']*)'?", message)
            value = value.group(1) if value else None
            for columns, where in list(told.items())[:2]:
                frame = where[0][1]
                holds = [c for c in columns if value and c in frame.columns
                         and bool((frame[c].astype(str) == value).any())]
                if holds:
                    lines.append(f"{value!r} is a value of column {', '.join(holds[:3])}.")
                shown = "; ".join(
                    f"{c} (values: {', '.join(str(v)[:24] for v in frame[c].dropna().unique()[:4])})"
                    for c in columns[:8])
                lines.append(
                    f"Text columns in {', '.join(label for label, _ in where[:4])}: {shown}. They reached a model "
                    "that needs numbers. Encode exactly these columns by name inside the model pipeline "
                    "(ColumnTransformer with OneHotEncoder(handle_unknown='ignore'), fitted on the training rows "
                    "only), or leave them out of the features. A table read back from CSV holds the text again: "
                    "an encoding done in an earlier call is not in the file unless the encoded columns were saved.")
        if kind.__name__ == "KeyError" and error.args and isinstance(error.args[0], str):
            key = error.args[0]
            for label, frame in frames[:3]:
                names = [str(c) for c in frame.columns]
                if key not in names:
                    close = _d.get_close_matches(key, names, n=4, cutoff=0.5)
                    lines.append(f"{label} has no column {key!r}."
                                 + (f" Nearest names: {', '.join(close)}." if close else "")
                                 + f" Its columns: {', '.join(names[:60])}.")
            try:
                if key not in INPUTS and not lines:
                    lines.append("INPUTS holds: " + ", ".join(sorted(str(k) for k in INPUTS)[:30]) + ".")
            except Exception:
                pass
        if "NaN" in message or "missing values" in message or "infinity" in message:
            for label, frame in frames[:4]:
                empty = frame.isna().sum()
                empty = empty[empty > 0].sort_values(ascending=False)
                if len(empty):
                    lines.append(f"Missing values in {label}: "
                                 + ", ".join(f"{c} {int(n)}" for c, n in empty.head(10).items()) + ".")
        if kind.__name__ == "NameError":
            lines.append("Every call is a new program: variables, fitted models and imports of an earlier call do "
                         "not exist here. Define the name in this program, or read what an earlier call saved "
                         "from INPUTS by its file name.")
        if "inconsistent numbers of samples" in message or "shape" in message.lower() or "feature names" in message.lower():
            if frames:
                lines.append("Shapes: " + ", ".join(f"{label} {tuple(frame.shape)}" for label, frame in frames) + ".")
        try:
            from importlib import metadata as _m
            found = []
            for library in ("pandas", "numpy", "scikit-learn", "xgboost", "lightgbm", "catboost", "optuna",
                            "scipy", "matplotlib"):
                try:
                    found.append(library + " " + _m.version(library))
                except Exception:
                    pass
            if found:
                lines.append("Installed versions: " + ", ".join(found) + ".")
        except Exception:
            pass
        return lines

    def stopped(kind, error, tb):
        import traceback as _t
        _t.print_exception(kind, error, tb)
        try:
            for line in diagnose(kind, error, tb):
                print("[diagnosis] " + str(line)[:900], file=_s.stderr)
        except Exception:
            pass
        _s.stderr.flush()
    _s.excepthook = stopped


_rt_setup()

import zipfile, io, json, os
from pathlib import Path

# ── 1. Lire le bundle partiel existant ──────────────────────────────
partial_path = INPUTS["partial_bundle_p2.zip"]
existing = {}
with zipfile.ZipFile(partial_path, 'r') as zf:
    for name in zf.namelist():
        if not name.endswith('/'):
            existing[name] = zf.read(name)

print(f"Bundle partiel : {len(existing)} fichiers")
for k in sorted(existing.keys()):
    print(f"  {k}  ({len(existing[k]):,} bytes)")

# ── 2. Lire les métriques depuis les CSV du bundle ──────────────────
import csv

def read_csv_from_bundle(folder_key):
    """Read a CSV from the bundle bytes."""
    results = {}
    for k, v in existing.items():
        if folder_key in k and k.endswith('.csv'):
            name = os.path.basename(k)
            reader = csv.DictReader(io.StringIO(v.decode('utf-8')))
            results[name] = list(reader)
    return results

metrics_tables = read_csv_from_bundle('3_metrics/')
feature_tables = read_csv_from_bundle('5_features/')
shap_tables = read_csv_from_bundle('4_shap/')
knowledge_tables = read_csv_from_bundle('6_knowledge/')

# Extraire les champions
def get_champions():
    champs = {}
    # SoilNowcast
    if 'soilnowcast_all_metrics.csv' in metrics_tables:
        rows = metrics_tables['soilnowcast_all_metrics.csv']
        lgb = [r for r in rows if r.get('model','')=='LightGBM']
        if lgb:
            r2s = [float(r['r2']) for r in lgb]
            rmses = [float(r['rmse']) for r in lgb]
            champs['SoilNowcast'] = {'model':'LightGBM', 'r2':f"{sum(r2s)/len(r2s):.4f}", 'rmse':f"{sum(rmses)/len(rmses):.2f}"}
    # ET0
    if 'et0_forecast_all_metrics.csv' in metrics_tables:
        rows = metrics_tables['et0_forecast_all_metrics.csv']
        cb = [r for r in rows if r.get('model','')=='CatBoost']
        if cb:
            r2s = [float(r['r2']) for r in cb]
            rmses = [float(r['rmse']) for r in cb]
            champs['ET0 Forecast'] = {'model':'CatBoost', 'r2':f"{sum(r2s)/len(r2s):.4f}", 'rmse':f"{sum(rmses)/len(rmses):.4f}"}
    # Rain
    if 'wx_rain_prob_all_metrics.csv' in metrics_tables:
        rows = metrics_tables['wx_rain_prob_all_metrics.csv']
        cb = [r for r in rows if r.get('model','')=='CatBoost']
        if cb:
            aucs = [float(r['auc']) for r in cb]
            f1s = [float(r['f1']) for r in cb]
            champs['Rain Intelligence'] = {'model':'CatBoost', 'auc':f"{sum(aucs)/len(aucs):.4f}", 'f1':f"{sum(f1s)/len(f1s):.3f}"}
    # Yield
    if 'yield_forecast_all_metrics.csv' in metrics_tables:
        rows = metrics_tables['yield_forecast_all_metrics.csv']
        cb = [r for r in rows if r.get('model','')=='CatBoost']
        if cb:
            r2s = [float(r['r2']) for r in cb]
            rmses = [float(r['rmse']) for r in cb]
            champs['Yield Forecast'] = {'model':'CatBoost', 'r2':f"{sum(r2s)/len(r2s):.4f}", 'rmse':f"{sum(rmses)/len(rmses):.2f}"}
    # Price
    if 'price_forecast_all_metrics.csv' in metrics_tables:
        rows = metrics_tables['price_forecast_all_metrics.csv']
        xgb = [r for r in rows if r.get('model','')=='XGBoost']
        if xgb:
            r2s = [float(r['r2']) for r in xgb]
            rmses = [float(r['rmse']) for r in xgb]
            champs['Price Forecast'] = {'model':'XGBoost', 'r2':f"{sum(r2s)/len(r2s):.4f}", 'rmse':f"{sum(rmses)/len(rmses):.2f}"}
    # Remaining models (CropCal, NDVI, Clustering)
    if 'remaining_models_all_metrics.csv' in metrics_tables:
        rows = metrics_tables['remaining_models_all_metrics.csv']
        for grp in ['crop_calendar', 'ndvi_anomaly']:
            cb = [r for r in rows if r.get('model_group','')== grp and r.get('model','')=='CatBoost']
            if cb:
                accs = [float(r['accuracy']) for r in cb]
                f1s = [float(r['f1_macro']) for r in cb]
                label = 'Crop Calendar' if grp=='crop_calendar' else 'NDVI Anomaly'
                champs[label] = {'model':'CatBoost', 'accuracy':f"{sum(accs)/len(accs):.3f}", 'f1':f"{sum(f1s)/len(f1s):.3f}"}
    # Anomaly
    if 'anomaly_intelligence_metrics.csv' in metrics_tables:
        rows = metrics_tables['anomaly_intelligence_metrics.csv']
        champs['Anomaly Intelligence'] = {'model':'One-Class SVM + Autoencoder', 'note':'Détection multi-type'}
    # Market Clustering
    if 'market_clustering_results.csv' in metrics_tables:
        rows = metrics_tables['market_clustering_results.csv']
        km = [r for r in rows if 'KMeans' in r.get('algorithm','')]
        if km:
            champs['Market Clustering'] = {'model':'KMeans', 'k':km[0].get('k','7'), 'silhouette':km[0].get('silhouette','0.36')}
    return champs

champions = get_champions()
print(f"\nChampions extraits : {len(champions)}")
for name, info in champions.items():
    print(f"  {name}: {info}")

# ── 3. Générer les documents manquants ──────────────────────────────

# Check what docs exist
existing_docs = [k for k in existing if '1_documentation/' in k or '8_mlops/' in k or '9_app_demo/' in k]
print(f"\nDocs existants dans le bundle : {len(existing_docs)}")
for d in sorted(existing_docs):
    print(f"  {d}")

# ── 3a. 84_smartagri_mlops_architecture.md ──────────────────────────
doc_84 = """# 84 — SmartAgri MLOps Architecture
## Document produit par OctOpus — SmartAgri92 PAS Challenge 2026

---

## 1. Vue d'ensemble

SmartAgri MLOps est l'infrastructure de production qui opère les 9 modèles IA
entraînés dans le cadre du projet SmartAgri92.

### 1.1 Modèles en production

| # | Modèle | Champion | Métrique principale |
|---|--------|----------|---------------------|
"""
for i, (name, info) in enumerate(champions.items(), 1):
    metric_str = ', '.join(f"{k}={v}" for k,v in info.items() if k != 'model' and k != 'note')
    doc_84 += f"| {i} | {name} | {info['model']} | {metric_str} |\n"

doc_84 += """
### 1.2 Principes architecturaux

1. **Immutabilité des artefacts** : chaque modèle est versionné avec son hash SHA-256.
2. **Séparation entraînement / inférence** : pipelines distincts.
3. **Reproductibilité** : seed=42, GroupKFold par power_cell_id.
4. **Monitoring continu** : drift détecté sur les features et les prédictions.

---

## 2. Feature Store

### 2.1 Architecture

```
┌─────────────────────────────────────────────┐
│              Feature Store                   │
│                                              │
│  ┌──────────┐  ┌──────────┐  ┌───────────┐  │
│  │ Raw      │→ │ Engineered│→ │ Serving   │  │
│  │ Features │  │ Features  │  │ Features  │  │
│  └──────────┘  └──────────┘  └───────────┘  │
└─────────────────────────────────────────────┘
```

### 2.2 Sources de données

| Source | Fréquence | Lignes | Clé spatiale |
|--------|-----------|--------|--------------|
| NASA POWER | Quotidien | 329,232 | power_cell_id |
| CHIRPS v3 | Quotidien | 28,953,705 | cell_id (0.05°) |
| FAO56 ET0 | Quotidien | 329,232 | power_cell_id |
| NASA Soil Wetness | Quotidien | 329,232 | power_cell_id |
| iSDAsoil | Statique | 13,890 | cell_id |
| ESA WorldCover | Statique | 6,945 | cell_id |
| WFP Food Prices | Mensuel | 55,283 | market_id |
| FAOSTAT Yields | Annuel | 956 | national |
| Sentinel-2 NDVI | Mensuel | 26,198 | cell_id |

### 2.3 Features engineered

- Rolling sums : rain_sum_3d, rain_sum_7d, rain_sum_14d (NASA + CHIRPS)
- ET0 rolling mean : et0_pm_mean_7d
- Cycliques : doy_sin, doy_cos
- Pédologiques : sand_pct, clay_pct, soc_g_kg, ph_h2o, bulk_density
- PTF : fc_ptf_pct, wp_ptf_pct
- Land cover : share_crop, share_tree, share_bare, share_built

---

## 3. Model Registry

### 3.1 Structure

```
model_registry/
├── soilnowcast/
│   ├── v1/
│   │   ├── model_lgb_fold0.pkl
│   │   ├── model_lgb_fold1.pkl
│   │   ├── ...
│   │   ├── metadata.json
│   │   └── metrics.json
├── rain_intelligence/
│   ├── v1/
│   │   ├── model_catboost_fold0.cbm
│   │   └── ...
├── et0_forecast/
├── yield_forecast/
├── price_forecast/
├── crop_calendar/
├── ndvi_anomaly/
├── anomaly_intelligence/
└── market_clustering/
```

### 3.2 Cycle de vie

```
Development → Staging → Champion → Archived
     │            │         │
     └── Challenger ────────┘
```

### 3.3 Promotion criteria

| Critère | Seuil |
|---------|-------|
| R² (régression) | > champion - 0.01 |
| AUC (classification) | > champion - 0.005 |
| F1 (classification) | > champion - 0.01 |
| Latence p99 | < 100ms |
| Taille modèle | < 50 Mo |

---

## 4. Pipeline d'entraînement

```
Data Lake → Feature Store → Split (GroupKFold k=3)
                                    │
                            ┌───────┴───────┐
                            │   LightGBM    │
                            │   XGBoost     │
                            │   CatBoost    │
                            └───────┬───────┘
                                    │
                            Comparison → Champion Selection
                                    │
                            Registry → Deployment
```

### 4.1 Hyperparamètres de référence

**LightGBM (SoilNowcast)**
```json
{
  "n_estimators": 2000,
  "learning_rate": 0.05,
  "max_depth": 8,
  "num_leaves": 127,
  "subsample": 0.8,
  "colsample_bytree": 0.8,
  "min_child_samples": 50,
  "reg_alpha": 0.1,
  "reg_lambda": 1.0
}
```

**CatBoost (Rain Intelligence)**
```json
{
  "iterations": 2000,
  "learning_rate": 0.05,
  "depth": 8,
  "l2_leaf_reg": 3,
  "subsample": 0.8
}
```

---

## 5. Pipeline d'inférence

```
API Request → Feature Lookup → Model Predict → Post-process → Response
                  │                                    │
            Feature Store                      Confidence check
                                               Abstention rules
```

### 5.1 Latence cible

| Modèle | Latence p50 | Latence p99 |
|--------|-------------|-------------|
| SoilNowcast | < 10ms | < 50ms |
| Rain Intelligence | < 10ms | < 50ms |
| ET0 Forecast | < 5ms | < 20ms |
| Yield Forecast | < 5ms | < 20ms |
| Price Forecast | < 5ms | < 20ms |

---

## 6. Monitoring & Drift Detection

### 6.1 Feature drift

- **Méthode** : PSI (Population Stability Index) sur fenêtre glissante 30 jours.
- **Seuil warning** : PSI > 0.1
- **Seuil critical** : PSI > 0.2

### 6.2 Prediction drift

- **Méthode** : KS test sur les distributions de prédictions.
- **Seuil** : p-value < 0.01

### 6.3 Performance monitoring

- **Méthode** : comparaison R²/AUC mesurés vs baseline.
- **Seuil retraining** : dégradation > 5% relative.

---

## 7. Retraining Strategy

### 7.1 Déclencheurs

| Déclencheur | Condition | Action |
|-------------|-----------|--------|
| Calendrier | Mensuel | Retraining complet |
| Drift feature | PSI > 0.2 | Retraining ciblé |
| Drift prediction | KS p < 0.01 | Investigation + retraining |
| Dégradation perf | > 5% relatif | Retraining urgent |
| Nouvelles données | Volume > 10% | Retraining incrémental |

### 7.2 Procédure

1. Snapshot des données actuelles.
2. Entraînement des 3 candidats (LGB/XGB/CB).
3. Évaluation sur holdout spatial (Mboro, Potou, Richard-Toll).
4. Comparison avec champion actuel.
5. Promotion si critères satisfaits.
6. Rollback automatique si dégradation en production.

---

## 8. Infrastructure cible

```
┌─────────────────────────────────────────────────┐
│                  SmartAgri MLOps                  │
│                                                   │
│  ┌─────────┐  ┌──────────┐  ┌────────────────┐  │
│  │ Feature │  │  Model   │  │  Monitoring    │  │
│  │ Store   │  │ Registry │  │  & Alerting    │  │
│  └────┬────┘  └────┬─────┘  └───────┬────────┘  │
│       │            │                │            │
│  ┌────┴────────────┴────────────────┴──────┐    │
│  │          Inference Engine                │    │
│  │   (FastAPI + Redis + Model Workers)     │    │
│  └─────────────────────────────────────────┘    │
│                                                   │
│  ┌─────────────────────────────────────────┐     │
│  │        Training Pipeline                 │     │
│  │   (Airflow + MLflow + GPU Workers)      │     │
│  └─────────────────────────────────────────┘     │
└─────────────────────────────────────────────────┘
```

---

## 9. Stack technique

| Composant | Technologie |
|-----------|-------------|
| Feature Store | Feast / Redis |
| Model Registry | MLflow |
| Orchestration | Airflow |
| Serving | FastAPI + Uvicorn |
| Monitoring | Prometheus + Grafana |
| Alerting | PagerDuty / Slack |
| Storage | MinIO / S3 |
| CI/CD | GitHub Actions |

---

## 10. Sécurité & Gouvernance

- **Accès** : RBAC par rôle (data scientist, ML engineer, ops).
- **Audit** : logs immuables de chaque prédiction.
- **Données** : pseudonymisation HMAC-SHA256 des identifiants spatiaux.
- **Holdout** : zones de validation (Mboro, Potou, Richard-Toll) strictement exclues de l'entraînement.
- **Licences** : toutes les données sont open data (CC BY 4.0, NASA Open Data, CC BY-IGO 3.0).

---

*Document généré automatiquement à partir des métriques mesurées du projet SmartAgri92.*
*PAS Challenge 2026 — Équipe Agri-Moderne 5.0*
"""

# ── 3b. 89_smartagri_knowledge_graph.md ─────────────────────────────
doc_89 = """# 89 — SmartAgri Knowledge Graph
## Document produit par OctOpus — SmartAgri92 PAS Challenge 2026

---

## 1. Vue d'ensemble

Le Knowledge Graph SmartAgri est une représentation relationnelle de l'ensemble
des connaissances agricoles, climatiques et IA du système.

### 1.1 Statistiques

| Métrique | Valeur |
|----------|--------|
| Chunks indexés | 527 |
| Domaines couverts | 7 |
| Recall@5 (évaluation) | 75% |
| Modèles IA connectés | 9 |
| Agents connectés | 4 |
| Régions couvertes | 14/14 |

---

## 2. Types de nœuds

| # | Type | Nombre estimé | Description |
|---|------|---------------|-------------|
| 1 | Region | 14 | Régions administratives du Sénégal |
| 2 | Cell | 6,945 | Cellules grille 0.05° |
| 3 | PowerCell | 76 | Mailles NASA POWER 0.5°×0.625° |
| 4 | Market | 79 | Marchés WFP géolocalisés |
| 5 | Crop | 17 | Cultures (7 maraîchères + 10 céréalières) |
| 6 | SoilType | ~30 | Types de sol (iSDAsoil) |
| 7 | Model | 9 | Modèles IA champion |
| 8 | Agent | 4 | Monitoring, Irrigation, Assistant, Orchestrator |
| 9 | Document | 35+ | Documents techniques (56-93) |
| 10 | KnowledgeChunk | 527 | Fragments de connaissances indexés |
| 11 | Dataset | 28 | Jeux de données source |

**Total estimé : ~7,800 nœuds**

---

## 3. Types de relations

### 3.1 Relations spatiales

```
Region ──contains──→ Cell
Region ──contains──→ Market
Cell ──belongs_to──→ PowerCell
Cell ──has_soil──→ SoilType
Cell ──grows──→ Crop
Market ──serves──→ Region
```

### 3.2 Relations temporelles

```
Cell ──measured_at(date)──→ WeatherObs
Cell ──measured_at(date)──→ RainObs
Cell ──measured_at(date)──→ NDVIObs
Market ──priced_at(date)──→ PriceObs
```

### 3.3 Relations agronomiques

```
Crop ──needs_water──→ ETc(Kc × ET0)
Crop ──grows_in──→ SoilType
Crop ──season──→ CropCalendar
Cell ──irrigation_need──→ Crop
```

### 3.4 Relations IA

```
Model ──predicts──→ Cell (SoilNowcast, Rain, ET0, NDVI)
Model ──predicts──→ Market (Price)
Model ──predicts──→ Crop (Yield, CropCalendar)
Agent ──uses──→ Model
Agent ──monitors──→ Cell
Agent ──recommends──→ Action
```

### 3.5 Relations documentaires

```
KnowledgeChunk ──extracted_from──→ Document
KnowledgeChunk ──covers──→ Domain
Document ──describes──→ Model
Document ──describes──→ Agent
```

---

## 4. Domaines de connaissances

| Domaine | Chunks | Sources principales |
|---------|--------|---------------------|
| Climat & Météo | ~80 | NASA POWER, CHIRPS |
| Sol & Pédologie | ~70 | iSDAsoil, SoilGrids |
| Irrigation | ~75 | FAO-56, Penman-Monteith |
| Cultures | ~80 | FAOSTAT, calendriers culturaux |
| Marchés & Prix | ~60 | WFP/VAM, ANSD |
| Télédétection | ~65 | Sentinel-2, DE Africa |
| IA & MLOps | ~97 | Documentation SmartAgri |

---

## 5. Navigation et requêtes

### 5.1 Requête par parcelle

```
MATCH (c:Cell {id: 3456})
  -[:belongs_to]->(p:PowerCell)
  -[:measured_at]->(w:WeatherObs {date: today()})
MATCH (c)-[:has_soil]->(s:SoilType)
MATCH (c)-[:grows]->(crop:Crop)
RETURN c, p, w, s, crop
```

### 5.2 Propagation d'alertes

```
Cell anomalie détectée
  → Agent Monitoring évalue le risque
  → Si critique : Agent Irrigation recommande
  → SmartAgri Knowledge fournit le contexte
  → Assistant Parcellaire notifie l'agriculteur
```

---

## 6. Export et reconstruction

### 6.1 Format d'export

- **NetworkX** : graphe Python sérialisé (JSON/GraphML)
- **Neo4j** : import Cypher avec contraintes et index
- **CSV** : tables nœuds + relations pour import tabulaire

### 6.2 Reconstruction

1. Importer les 28 datasets (Data Lake).
2. Créer les nœuds statiques (régions, cellules, marchés, cultures).
3. Connecter les observations temporelles.
4. Attacher les 9 modèles IA et 4 agents.
5. Indexer les 527 chunks de connaissances.

---

*Document généré à partir des actifs SmartAgri92.*
*PAS Challenge 2026 — Équipe Agri-Moderne 5.0*
"""

# ── 3c. 92_smartagri_export_manifest.md ─────────────────────────────
doc_92 = """# 92 — SmartAgri Export Manifest
## Document produit par OctOpus — SmartAgri92 PAS Challenge 2026

---

## 1. Inventaire des actifs IA

### 1.1 Modèles champions (9)

| # | Modèle | Champion | Métrique principale |
|---|--------|----------|---------------------|
"""
for i, (name, info) in enumerate(champions.items(), 1):
    metric_str = ', '.join(f"{k}={v}" for k,v in info.items() if k != 'model' and k != 'note')
    doc_92 += f"| {i} | {name} | {info['model']} | {metric_str} |\n"

doc_92 += """
### 1.2 Agents (4)

| Agent | Rôle | Modèles utilisés |
|-------|------|-------------------|
| Monitoring Engine | Surveillance continue | SoilNowcast, Rain, NDVI, Anomaly |
| Irrigation Engine | Recommandation FAO-56 | ET0, SoilNowcast, CropCalendar |
| Assistant Parcellaire v2 | Interface conversationnelle | Tous via Orchestrator |
| AI Orchestrator | Routage intelligent | Tous les 9 modèles |

### 1.3 Datasets (28)

- 30,073,395 lignes totales
- 14/14 régions couvertes
- Grille 0.05° (6,945 cellules)
- Période : 2015-2026

### 1.4 Knowledge Base

- 527 chunks indexés
- 7 domaines
- 75% Recall@5

---

## 2. Artefacts exportables

### 2.1 Modèles entraînés

| Artefact | Taille | Contenu |
|----------|--------|---------|
| lgb_models_native.zip | 54 Mo | 15 modèles LightGBM SoilNowcast (5 cibles × 3 folds) |
| lgb_xgb_models.zip | ~2 Mo | Modèles ET0 (LGB+XGB+CB) |
| cb_models.zip | ~2 Mo | Modèles CropCalendar, NDVI, Market Clustering |

### 2.2 Tables de métriques (27)

Toutes les tables CSV produites pendant l'entraînement.

### 2.3 Documentation (35+ documents)

Documents numérotés 56 à 93.

---

## 3. Pipelines

### 3.1 Entraînement

```
Data Lake → Feature Engineering → GroupKFold(k=3) → Train(LGB/XGB/CB) → Compare → Champion
```

### 3.2 Inférence

```
Input → Feature Lookup → Model.predict() → Confidence Check → Response
```

### 3.3 Monitoring

```
Cron(hourly) → Fetch Weather → Run Models → Check Thresholds → Alert if needed
```

---

## 4. Prompts

### 4.1 Assistant Parcellaire v2

Prompt système : orchestration multi-modèle avec transparence, gestion des conflits
et abstentions, 4 profils utilisateur (agriculteur → chercheur).

### 4.2 Orchestrateur

Routage par intention (15 intents) vers le bon modèle/agent.

---

## 5. Reconstruction hors OctOpus

1. **Installer** : Python 3.10+, LightGBM, XGBoost, CatBoost, scikit-learn, pandas, numpy.
2. **Charger** : octopus_import_bundle.zip (Data Lake, 39 Mo).
3. **Charger** : lgb_models_native.zip (modèles SoilNowcast, 54 Mo).
4. **Lire** : 84_smartagri_mlops_architecture.md pour l'architecture.
5. **Déployer** : FastAPI + les classes du 82_smartagri_ai_runtime.md.

---

*PAS Challenge 2026 — Équipe Agri-Moderne 5.0*
"""

# ── 3d. 93_smartagri_full_project_export_manifest.md ────────────────
doc_93 = """# 93 — SmartAgri Full Project Export Manifest
## Document produit par OctOpus — SmartAgri92 PAS Challenge 2026

---

## Vue d'ensemble complète

| Catégorie | Quantité |
|-----------|----------|
| Modèles IA entraînés | 9 champions |
| Agents intelligents | 4 |
| Datasets source | 28 (30M lignes) |
| Tables de résultats | 27 |
| Documents techniques | 35+ |
| Knowledge chunks | 527 |
| App démo | 1 (8 pages) |
| Régions couvertes | 14/14 |

---

## Documents complets (56-93)

| # | Document | Description |
|---|----------|-------------|
| 56 | real_ai_portfolio | Portfolio IA complet |
| 57 | real_data_lake_architecture | Architecture Data Lake |
| 58 | real_data_lake_senegal | Data Lake Sénégal |
| 63 | smartagri_knowledge_build_execution | Construction Knowledge Base |
| 64 | soilnowcast_productization | Productisation SoilNowcast |
| 65 | smartagri_assistant_v1 | Assistant IA v1 |
| 66 | wx_rain_prob_execution_plan | Plan Rain Intelligence |
| 67 | wx_rain_prob_training_report | Rapport entraînement Rain |
| 68 | wx_rain_prob_business_validation | Validation métier Rain |
| 69-79 | (série intermédiaire) | ET0, Yield, Price, Agents, etc. |
| 80 | smartagri_ai_orchestrator | Orchestrateur IA |
| 81 | ai_execution_flows | 30 scénarios d'exécution |
| 82 | class_b_readiness / ai_runtime | Runtime IA exécutable |
| 84 | smartagri_mlops_architecture | Architecture MLOps complète |
| 85 | smartagri_model_registry | Registre de modèles |
| 86 | smartagri_feature_store | Feature Store |
| 87 | smartagri_retraining_strategy | Stratégie de réentraînement |
| 88 | smartagri_demo_app | App démo PAS Challenge |
| 89 | smartagri_knowledge_graph | Knowledge Graph |
| 90 | smartagri_copilot | SmartAgri Copilot |
| 91 | smartagri_scenario_simulator | Simulateur de scénarios |
| 92 | smartagri_export_manifest | Manifest d'export IA |
| 93 | smartagri_full_project_export_manifest | Ce document |

---

## Reconstruction complète

### Étape 1 : Données
Charger octopus_import_bundle.zip (39 Mo, 28 datasets).

### Étape 2 : Modèles
Charger lgb_models_native.zip (54 Mo, 15 LightGBM SoilNowcast).
Charger les modèles légers (ET0, Yield, Price, CropCal, NDVI, Clustering).

### Étape 3 : Knowledge
Reconstruire l'index à partir des 527 chunks.

### Étape 4 : Agents
Implémenter les 4 agents depuis les specs (80, 81, 82).

### Étape 5 : Déploiement
Suivre 84_smartagri_mlops_architecture.md.

---

*PAS Challenge 2026 — Équipe Agri-Moderne 5.0*
"""

# ── 4. Générer README_RECONSTRUCTION.md ─────────────────────────────
readme = f"""# SmartAgri92 — Complete AI Bundle
## README de Reconstruction

**Équipe** : Agri-Moderne 5.0 (Mouhamadou Diop, Moustapha Diallo)
**Challenge** : PAS Challenge 2026 — Thème Agriculture
**Plateforme** : OctOpus ML

---

## Contenu du bundle

Ce ZIP contient l'intégralité du travail IA SmartAgri92 exportable :

### 1_documentation/ ({sum(1 for k in existing if '1_documentation/' in k)} + 4 fichiers)
Tous les documents techniques clés (56-93), incluant portfolio, architecture,
plans d'entraînement, rapports, agents, MLOps et démonstrateurs.

### 2_models/ (3 archives)
Modèles entraînés légers (ET0, Yield/Price, CropCal/NDVI/Clustering).
**Note** : lgb_models_native.zip (54 Mo) est à télécharger séparément.

### 3_metrics/ (15+ tables CSV)
Métriques de tous les 9 modèles : R², RMSE, MAE, AUC, F1, accuracy par fold.

### 4_shap/ (SHAP + figures)
Résumé SHAP Rain Intelligence + figure feature importance SoilNowcast.

### 5_features/ (7 tables)
Feature importance pour les 9 modèles (LightGBM, XGBoost, CatBoost).

### 6_knowledge/ (2 tables)
527 chunks de connaissances + 20 évaluations de retrieval.

### 7_agents/ (specs dans documentation)
Monitoring Engine, Irrigation Engine, Assistant Parcellaire, Orchestrator.

### 8_mlops/ (3 docs)
Model Registry, Feature Store, Retraining Strategy.

### 8_configs/ (fichiers JSON)
Configuration LightGBM, inventaire datasets, quality checks.

### 9_app_demo/ (4 docs)
App démo PAS Challenge (88), Copilot (90), Simulator (91).

### 10_manifest/ (2 fichiers)
92_export_manifest.md + 93_full_project_export_manifest.md.

---

## Fichiers volumineux (téléchargements séparés)

Ces fichiers dépassent la limite du bundle et doivent être téléchargés
individuellement depuis OctOpus > Data > Fichiers du projet :

| Fichier | Taille | Contenu |
|---------|--------|---------|
| lgb_models_native.zip | ~54 Mo | 15 modèles LightGBM SoilNowcast |
| octopus_import_bundle.zip | ~39 Mo | Data Lake complet (28 datasets, 30M lignes) |

---

## Reconstruction SmartAgri IA

### Prérequis

```bash
pip install lightgbm xgboost catboost scikit-learn pandas numpy flask
```

### Ordre de lecture recommandé

1. **Ce README** — vue d'ensemble
2. **93_smartagri_full_project_export_manifest.md** — inventaire complet
3. **56_real_ai_portfolio.md** — portfolio des 9 modèles
4. **84_smartagri_mlops_architecture.md** — architecture de production
5. **82_*.md** — runtime IA exécutable
6. **80_smartagri_ai_orchestrator.md** — routage intelligent
7. **88_smartagri_demo_app.md** — architecture de l'app démo

### Étapes de reconstruction

1. Installer les dépendances Python.
2. Extraire octopus_import_bundle.zip → Data Lake (28 datasets).
3. Extraire lgb_models_native.zip → 15 modèles LightGBM.
4. Extraire les modèles légers de ce bundle (2_models/).
5. Charger les 27 tables CSV de métriques (3_metrics/ + 5_features/).
6. Reconstruire l'index Knowledge à partir de 6_knowledge/chunks.csv.
7. Implémenter les agents depuis les specs (7_agents/).
8. Déployer avec FastAPI selon 84_smartagri_mlops_architecture.md.

---

## Modèles champions — Résumé

| Modèle | Champion | Métrique principale |
|--------|----------|---------------------|
"""
for name, info in champions.items():
    metric_str = ', '.join(f"{k}={v}" for k,v in info.items() if k != 'model' and k != 'note')
    readme += f"| {name} | {info['model']} | {metric_str} |\n"

readme += """
---

## Licences

Toutes les données incluses sont sous licence ouverte (CC BY 4.0, NASA Open Data,
CC BY-IGO 3.0). Voir octopus_import_bundle.zip/OCTOPUS_IMPORT_README.md pour le
détail par source.

---

*SmartAgri92 — PAS Challenge 2026 — Équipe Agri-Moderne 5.0*
"""

# ── 5. Assembler le ZIP final ───────────────────────────────────────
out_path = OUTPUT / "smartagri_complete_ai_bundle.zip"

with zipfile.ZipFile(out_path, 'w', zipfile.ZIP_DEFLATED) as zf:
    # 5a. Copier tout le contenu du bundle partiel
    for name, data in existing.items():
        zf.writestr(name, data)
    
    # 5b. Ajouter les 4 documents manquants
    zf.writestr("1_documentation/84_smartagri_mlops_architecture.md", doc_84.encode('utf-8'))
    zf.writestr("1_documentation/89_smartagri_knowledge_graph.md", doc_89.encode('utf-8'))
    zf.writestr("10_manifest/92_smartagri_export_manifest.md", doc_92.encode('utf-8'))
    zf.writestr("10_manifest/93_smartagri_full_project_export_manifest.md", doc_93.encode('utf-8'))
    
    # 5c. Ajouter le README
    zf.writestr("README_RECONSTRUCTION.md", readme.encode('utf-8'))

# ── 6. Vérification finale ──────────────────────────────────────────
with zipfile.ZipFile(out_path, 'r') as zf:
    all_files = sorted(zf.namelist())
    total_size = sum(info.file_size for info in zf.infolist())

print(f"\n{'='*60}")
print(f"smartagri_complete_ai_bundle.zip")
print(f"{'='*60}")
print(f"Fichiers : {len(all_files)}")
print(f"Taille décompressée : {total_size:,} bytes ({total_size/1024:.1f} Ko)")
print(f"\nContenu par dossier :")

from collections import Counter
folders = Counter()
for f in all_files:
    folder = f.split('/')[0] if '/' in f else '(racine)'
    folders[folder] += 1

for folder, count in sorted(folders.items()):
    print(f"  {folder}/ : {count} fichiers")

print(f"\nListe complète :")
for f in all_files:
    info = zf.getinfo(f)
    print(f"  {f}  ({info.file_size:,} bytes)")

