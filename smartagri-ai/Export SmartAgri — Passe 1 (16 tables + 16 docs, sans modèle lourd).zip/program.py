from pathlib import Path
import numpy as np
import pandas as pd
SEED = 42
rng = np.random.default_rng(SEED)
OUTPUT = Path("output")
OUTPUT.mkdir(exist_ok=True)
INPUTS = {key: str(Path("inputs") / key) for key in ['pf_0400f6345c6e476c9458d7e2', 'pf_a2301d71eac04bb4b00555bd', 'pf_3f687668f38b4235afc768ad', 'pf_201ceb347c294cf68e966051', 'pf_c128508f11234964ae098fec', 'pf_f93bd47d9cf849cfad22f59c', 'pf_d1ca015b22704769b2314110', 'pf_6c569c9af4ac42589a3fcd64', 'pf_320c851aa2b9480898970e13', 'pf_a1448bd2aaf94add8919db90', 'pf_f3cfa1fa30964e0ab92c0436', 'pf_626565a44af04ad6b2f4d7d1', 'pf_0700493ce9fa4e2f9f1cdb10', 'pf_622096639d614e0688ed1030', 'pf_702c332dd93348e180cfa3e3', 'pf_3ebd64cd3bc649d687cfbe3d', 'dat_ab646db01ad5', 'dat_8a25b526a892', 'dat_1b06400c0a9d', 'dat_36b2d399d572', 'dat_f3036f2fb909', 'dat_960302d77246', 'dat_b5a270a6e205', 'dat_b2bfe7c25bd3', 'dat_dedbae9f26dc', 'dat_0927e7a5f87c', 'dat_266cbb9747a3', 'dat_cc168f5c1214', 'dat_0ab56260700f', 'dat_b0e0cff523e1', 'dat_aef8044c0a30', 'dat_7764b6dc996a']}
def progress(message="", **fields):
    import json as _j, sys as _s, time as _t
    try:
        _r = dict(fields, message=str(message)[:200], t=round(_t.time(), 2))
        _l = _j.dumps(_r, default=str)
        print("[progress] " + _l, flush=True)
        with open(OUTPUT / ".progress.jsonl", "a") as _f:
            _f.write(_l + "\n")
    except Exception:
        pass
def _rt_setup():
    import json as _j, sys as _s
    here = globals().get("__file__")
    try:
        pd.set_option("future.infer_string", False)
        _select = pd.DataFrame.select_dtypes

        def select_dtypes(self, include=None, exclude=None):
            def classic(value):
                if value is None:
                    return None
                items = list(value) if isinstance(value, (list, tuple, set, frozenset)) else [value]
                out = []
                for item in items:
                    if item is str or (isinstance(item, str) and item in ("str", "string")):
                        out.append(object)
                        if item == "string":
                            out.append(item)
                    else:
                        out.append(item)
                return [x for i, x in enumerate(out) if not any(x is y for y in out[:i])]
            return _select(self, include=classic(include), exclude=classic(exclude))
        pd.DataFrame.select_dtypes = select_dtypes
    except Exception:
        pass
    _base = _j.JSONEncoder.default

    def default(self, value):
        if isinstance(value, np.generic):
            return value.item()
        if isinstance(value, np.ndarray):
            return value.tolist()
        if isinstance(value, (pd.Series, pd.Index)):
            return value.tolist()
        if isinstance(value, pd.DataFrame):
            return value.to_dict(orient="records")
        if isinstance(value, (pd.Timestamp, pd.Timedelta, Path)):
            return str(value)
        if isinstance(value, (set, frozenset)):
            return sorted(value, key=str)
        if value is pd.NA or value is pd.NaT:
            return None
        return _base(self, value)
    _j.JSONEncoder.default = default

    def diagnose(kind, error, tb):
        import re as _r, difflib as _d
        lines, message, frames, seen = [], str(error), [], set()

        def collect(space):
            for key, value in list(space.items()):
                if isinstance(value, pd.DataFrame) and id(value) not in seen and not str(key).startswith("_"):
                    seen.add(id(value))
                    frames.append((str(key), value))
        step = tb
        while step is not None:
            if step.tb_frame.f_code.co_filename == here:
                collect(step.tb_frame.f_locals)
            step = step.tb_next
        collect(globals())
        frames = frames[:8]

        def text_columns(frame):
            return [c for c in frame.columns if not (pd.api.types.is_numeric_dtype(frame[c])
                    or pd.api.types.is_bool_dtype(frame[c]) or pd.api.types.is_datetime64_any_dtype(frame[c]))]
        if "could not convert string to" in message:
            told = {}
            for label, frame in frames:
                columns = tuple(str(c) for c in text_columns(frame))
                if columns:
                    told.setdefault(columns, []).append((label, frame))
            value = _r.search(r"could not convert string to \w+: '?([^']*)'?", message)
            value = value.group(1) if value else None
            for columns, where in list(told.items())[:2]:
                frame = where[0][1]
                holds = [c for c in columns if value and c in frame.columns
                         and bool((frame[c].astype(str) == value).any())]
                if holds:
                    lines.append(f"{value!r} is a value of column {', '.join(holds[:3])}.")
                shown = "; ".join(
                    f"{c} (values: {', '.join(str(v)[:24] for v in frame[c].dropna().unique()[:4])})"
                    for c in columns[:8])
                lines.append(
                    f"Text columns in {', '.join(label for label, _ in where[:4])}: {shown}. They reached a model "
                    "that needs numbers. Encode exactly these columns by name inside the model pipeline "
                    "(ColumnTransformer with OneHotEncoder(handle_unknown='ignore'), fitted on the training rows "
                    "only), or leave them out of the features. A table read back from CSV holds the text again: "
                    "an encoding done in an earlier call is not in the file unless the encoded columns were saved.")
        if kind.__name__ == "KeyError" and error.args and isinstance(error.args[0], str):
            key = error.args[0]
            for label, frame in frames[:3]:
                names = [str(c) for c in frame.columns]
                if key not in names:
                    close = _d.get_close_matches(key, names, n=4, cutoff=0.5)
                    lines.append(f"{label} has no column {key!r}."
                                 + (f" Nearest names: {', '.join(close)}." if close else "")
                                 + f" Its columns: {', '.join(names[:60])}.")
            try:
                if key not in INPUTS and not lines:
                    lines.append("INPUTS holds: " + ", ".join(sorted(str(k) for k in INPUTS)[:30]) + ".")
            except Exception:
                pass
        if "NaN" in message or "missing values" in message or "infinity" in message:
            for label, frame in frames[:4]:
                empty = frame.isna().sum()
                empty = empty[empty > 0].sort_values(ascending=False)
                if len(empty):
                    lines.append(f"Missing values in {label}: "
                                 + ", ".join(f"{c} {int(n)}" for c, n in empty.head(10).items()) + ".")
        if kind.__name__ == "NameError":
            lines.append("Every call is a new program: variables, fitted models and imports of an earlier call do "
                         "not exist here. Define the name in this program, or read what an earlier call saved "
                         "from INPUTS by its file name.")
        if "inconsistent numbers of samples" in message or "shape" in message.lower() or "feature names" in message.lower():
            if frames:
                lines.append("Shapes: " + ", ".join(f"{label} {tuple(frame.shape)}" for label, frame in frames) + ".")
        try:
            from importlib import metadata as _m
            found = []
            for library in ("pandas", "numpy", "scikit-learn", "xgboost", "lightgbm", "catboost", "optuna",
                            "scipy", "matplotlib"):
                try:
                    found.append(library + " " + _m.version(library))
                except Exception:
                    pass
            if found:
                lines.append("Installed versions: " + ", ".join(found) + ".")
        except Exception:
            pass
        return lines

    def stopped(kind, error, tb):
        import traceback as _t
        _t.print_exception(kind, error, tb)
        try:
            for line in diagnose(kind, error, tb):
                print("[diagnosis] " + str(line)[:900], file=_s.stderr)
        except Exception:
            pass
        _s.stderr.flush()
    _s.excepthook = stopped


_rt_setup()

import zipfile, json
from pathlib import Path

# Resolve all available inputs
entries = {}  # arcname -> bytes

# Map file IDs to known names
PF_MAP = {
    'pf_0400f6345c6e476c9458d7e2': '56_real_ai_portfolio.md',
    'pf_a2301d71eac04bb4b00555bd': '57_first_octopus_projects.md',
}

for name, path in sorted(INPUTS.items()):
    p = Path(path)
    data = p.read_bytes()
    
    # Resolve name
    real_name = PF_MAP.get(name, name)
    
    # Skip dat_ duplicates (they duplicate the named table)
    if real_name.startswith('dat_'):
        continue
    
    # Classify
    ext = Path(real_name).suffix.lower()
    if ext == '.md':
        folder = 'documents'
    elif ext == '.csv':
        folder = 'tables'
    elif ext == '.json':
        folder = 'configs'
    elif ext == '.png':
        folder = 'figures'
    elif ext == '.zip':
        folder = 'models'
    else:
        folder = 'other'
    
    arcname = f"{folder}/{real_name}"
    entries[arcname] = data

# Write ZIP
out = OUTPUT / "smartagri_export_pass1.zip"
with zipfile.ZipFile(out, 'w', zipfile.ZIP_DEFLATED) as zf:
    for arcname, data in sorted(entries.items()):
        zf.writestr(arcname, data)

size_kb = out.stat().st_size / 1024
print(f"Passe 1: {len(entries)} fichiers, {size_kb:.0f} Ko")
for folder in sorted(set(k.split('/')[0] for k in entries)):
    items = [k for k in entries if k.startswith(folder + '/')]
    total = sum(len(entries[k]) for k in items) / 1024
    print(f"  {folder}/: {len(items)} fichiers ({total:.0f} Ko)")
    for k in sorted(items):
        print(f"    {k.split('/')[-1]}")

