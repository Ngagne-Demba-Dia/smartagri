from pathlib import Path
import numpy as np
import pandas as pd
SEED = 42
rng = np.random.default_rng(SEED)
OUTPUT = Path("output")
OUTPUT.mkdir(exist_ok=True)
INPUTS = {key: str(Path("inputs") / key) for key in ['pf_36a0bd77059143fe90ef40cf', 'pf_320c851aa2b9480898970e13', 'pf_a1448bd2aaf94add8919db90', 'pf_f3cfa1fa30964e0ab92c0436', 'pf_46ca3f9d743d4dda84eccef3', 'pf_626565a44af04ad6b2f4d7d1', 'pf_0700493ce9fa4e2f9f1cdb10', 'pf_622096639d614e0688ed1030', 'pf_702c332dd93348e180cfa3e3', 'pf_3ebd64cd3bc649d687cfbe3d', 'pf_a8653e299e394b18af9d7fb6', 'dat_5b0f9cf44bf6', 'dat_c7fb5876956c', 'dat_b5ab13cee7be', 'dat_89ef65c5b6df', 'dat_a23efbae3451', 'dat_bbef191980a3', 'dat_106438afb1ed', 'dat_9ed6ee755b75', 'dat_030266797f68']}
def progress(message="", **fields):
    import json as _j, sys as _s, time as _t
    try:
        _r = dict(fields, message=str(message)[:200], t=round(_t.time(), 2))
        _l = _j.dumps(_r, default=str)
        print("[progress] " + _l, flush=True)
        with open(OUTPUT / ".progress.jsonl", "a") as _f:
            _f.write(_l + "\n")
    except Exception:
        pass
def _rt_setup():
    import json as _j, sys as _s
    here = globals().get("__file__")
    try:
        pd.set_option("future.infer_string", False)
        _select = pd.DataFrame.select_dtypes

        def select_dtypes(self, include=None, exclude=None):
            def classic(value):
                if value is None:
                    return None
                items = list(value) if isinstance(value, (list, tuple, set, frozenset)) else [value]
                out = []
                for item in items:
                    if item is str or (isinstance(item, str) and item in ("str", "string")):
                        out.append(object)
                        if item == "string":
                            out.append(item)
                    else:
                        out.append(item)
                return [x for i, x in enumerate(out) if not any(x is y for y in out[:i])]
            return _select(self, include=classic(include), exclude=classic(exclude))
        pd.DataFrame.select_dtypes = select_dtypes
    except Exception:
        pass
    _base = _j.JSONEncoder.default

    def default(self, value):
        if isinstance(value, np.generic):
            return value.item()
        if isinstance(value, np.ndarray):
            return value.tolist()
        if isinstance(value, (pd.Series, pd.Index)):
            return value.tolist()
        if isinstance(value, pd.DataFrame):
            return value.to_dict(orient="records")
        if isinstance(value, (pd.Timestamp, pd.Timedelta, Path)):
            return str(value)
        if isinstance(value, (set, frozenset)):
            return sorted(value, key=str)
        if value is pd.NA or value is pd.NaT:
            return None
        return _base(self, value)
    _j.JSONEncoder.default = default

    def diagnose(kind, error, tb):
        import re as _r, difflib as _d
        lines, message, frames, seen = [], str(error), [], set()

        def collect(space):
            for key, value in list(space.items()):
                if isinstance(value, pd.DataFrame) and id(value) not in seen and not str(key).startswith("_"):
                    seen.add(id(value))
                    frames.append((str(key), value))
        step = tb
        while step is not None:
            if step.tb_frame.f_code.co_filename == here:
                collect(step.tb_frame.f_locals)
            step = step.tb_next
        collect(globals())
        frames = frames[:8]

        def text_columns(frame):
            return [c for c in frame.columns if not (pd.api.types.is_numeric_dtype(frame[c])
                    or pd.api.types.is_bool_dtype(frame[c]) or pd.api.types.is_datetime64_any_dtype(frame[c]))]
        if "could not convert string to" in message:
            told = {}
            for label, frame in frames:
                columns = tuple(str(c) for c in text_columns(frame))
                if columns:
                    told.setdefault(columns, []).append((label, frame))
            value = _r.search(r"could not convert string to \w+: '?([^']*)'?", message)
            value = value.group(1) if value else None
            for columns, where in list(told.items())[:2]:
                frame = where[0][1]
                holds = [c for c in columns if value and c in frame.columns
                         and bool((frame[c].astype(str) == value).any())]
                if holds:
                    lines.append(f"{value!r} is a value of column {', '.join(holds[:3])}.")
                shown = "; ".join(
                    f"{c} (values: {', '.join(str(v)[:24] for v in frame[c].dropna().unique()[:4])})"
                    for c in columns[:8])
                lines.append(
                    f"Text columns in {', '.join(label for label, _ in where[:4])}: {shown}. They reached a model "
                    "that needs numbers. Encode exactly these columns by name inside the model pipeline "
                    "(ColumnTransformer with OneHotEncoder(handle_unknown='ignore'), fitted on the training rows "
                    "only), or leave them out of the features. A table read back from CSV holds the text again: "
                    "an encoding done in an earlier call is not in the file unless the encoded columns were saved.")
        if kind.__name__ == "KeyError" and error.args and isinstance(error.args[0], str):
            key = error.args[0]
            for label, frame in frames[:3]:
                names = [str(c) for c in frame.columns]
                if key not in names:
                    close = _d.get_close_matches(key, names, n=4, cutoff=0.5)
                    lines.append(f"{label} has no column {key!r}."
                                 + (f" Nearest names: {', '.join(close)}." if close else "")
                                 + f" Its columns: {', '.join(names[:60])}.")
            try:
                if key not in INPUTS and not lines:
                    lines.append("INPUTS holds: " + ", ".join(sorted(str(k) for k in INPUTS)[:30]) + ".")
            except Exception:
                pass
        if "NaN" in message or "missing values" in message or "infinity" in message:
            for label, frame in frames[:4]:
                empty = frame.isna().sum()
                empty = empty[empty > 0].sort_values(ascending=False)
                if len(empty):
                    lines.append(f"Missing values in {label}: "
                                 + ", ".join(f"{c} {int(n)}" for c, n in empty.head(10).items()) + ".")
        if kind.__name__ == "NameError":
            lines.append("Every call is a new program: variables, fitted models and imports of an earlier call do "
                         "not exist here. Define the name in this program, or read what an earlier call saved "
                         "from INPUTS by its file name.")
        if "inconsistent numbers of samples" in message or "shape" in message.lower() or "feature names" in message.lower():
            if frames:
                lines.append("Shapes: " + ", ".join(f"{label} {tuple(frame.shape)}" for label, frame in frames) + ".")
        try:
            from importlib import metadata as _m
            found = []
            for library in ("pandas", "numpy", "scikit-learn", "xgboost", "lightgbm", "catboost", "optuna",
                            "scipy", "matplotlib"):
                try:
                    found.append(library + " " + _m.version(library))
                except Exception:
                    pass
            if found:
                lines.append("Installed versions: " + ", ".join(found) + ".")
        except Exception:
            pass
        return lines

    def stopped(kind, error, tb):
        import traceback as _t
        _t.print_exception(kind, error, tb)
        try:
            for line in diagnose(kind, error, tb):
                print("[diagnosis] " + str(line)[:900], file=_s.stderr)
        except Exception:
            pass
        _s.stderr.flush()
    _s.excepthook = stopped


_rt_setup()

import zipfile, pathlib, json

p1 = pathlib.Path(INPUTS["partial_bundle_p1.zip"])
zpath = OUTPUT / "partial_bundle_p2.zip"

with zipfile.ZipFile(p1, 'r') as zin:
    with zipfile.ZipFile(zpath, 'w', zipfile.ZIP_DEFLATED) as zf:
        # Copy pass 1
        for item in zin.namelist():
            zf.writestr(item, zin.read(item))
        m = json.loads(zin.read("_manifest_p1.json"))
        existing_names = {t["name"] for t in m["tables"]} | {d["name"] for d in m["documents"]}

        # ── REMAINING TABLES ─────────────────────────────────
        remaining = [
            "remaining_models_all_metrics.csv", "market_cluster_assignments.csv",
            "market_clustering_results.csv", "anomaly_intelligence_metrics.csv",
            "anomaly_intelligence_feature_importance.csv",
            "smartagri_knowledge_chunks.csv", "smartagri_knowledge_eval.csv",
            "lgb_fold_metrics.csv", "lgb_feature_importance.csv",
        ]
        for i, tname in enumerate(remaining):
            if tname in INPUTS and tname not in existing_names:
                p = pathlib.Path(INPUTS[tname])
                df = pd.read_parquet(p) if p.suffix == '.parquet' else pd.read_csv(p)
                buf = df.to_csv(index=False)
                if 'knowledge' in tname:
                    zf.writestr(f"6_knowledge/{tname}", buf)
                elif 'feature_importance' in tname:
                    zf.writestr(f"5_features/{tname}", buf)
                else:
                    zf.writestr(f"3_metrics/{tname}", buf)
                m["tables"].append({"name": tname, "rows": len(df), "cols": len(df.columns)})
                progress(f"Table {tname}", done=i+1, total=len(remaining))

        # ── DOCS 86-93 (standalone .md) ──────────────────────
        doc_routing = {
            "86_smartagri_feature_store.md": "8_mlops",
            "87_smartagri_retraining_strategy.md": "8_mlops",
            "88_smartagri_demo_app.md": "9_app_demo",
            "88_smartagri_digital_agronomist.md": "1_documentation",
            "89_smartagri_knowledge_graph.md": "1_documentation",
            "90_smartagri_copilot.md": "9_app_demo",
            "91_smartagri_scenario_simulator.md": "9_app_demo",
            "92_smartagri_export_manifest.md": "1_documentation",
            "93_smartagri_full_project_export_manifest.md": "10_manifest",
        }
        for dname, folder in doc_routing.items():
            if dname in INPUTS and dname not in existing_names:
                data = pathlib.Path(INPUTS[dname]).read_bytes()
                zf.writestr(f"{folder}/{dname}", data)
                m["documents"].append({"name": dname, "bytes": len(data)})

        # ── EXTRACT 85 from ZIP ──────────────────────────────
        zip85_name = "85_model_registry + 86_feature_store.zip"
        if zip85_name in INPUTS:
            with zipfile.ZipFile(INPUTS[zip85_name], 'r') as z85:
                for member in z85.namelist():
                    if member.endswith('.md') and '85' in member:
                        data = z85.read(member)
                        fname = member.split('/')[-1] if '/' in member else member
                        if fname not in existing_names:
                            zf.writestr(f"8_mlops/{fname}", data)
                            m["documents"].append({"name": fname, "bytes": len(data)})

        # ── SCAN for any other .md in INPUTS ─────────────────
        for key in sorted(INPUTS.keys()):
            if key.endswith('.md') and key not in existing_names:
                already = any(d["name"] == key for d in m["documents"])
                if not already:
                    data = pathlib.Path(INPUTS[key]).read_bytes()
                    zf.writestr(f"1_documentation/{key}", data)
                    m["documents"].append({"name": key, "bytes": len(data)})

        zf.writestr("_manifest_p2.json", json.dumps(m, indent=2, ensure_ascii=False))

sz = zpath.stat().st_size
print(f"Pass 2 ZIP: {sz/1024:.1f} Ko")
print(f"  tables: {len(m['tables'])}")
print(f"  documents: {len(m['documents'])}")
print(f"  models: {len(m['models'])}")
print(f"  configs: {len(m['configs'])}")
print(f"  figures: {len(m['figures'])}")
print(f"\nDoc names:")
for d in m['documents']:
    print(f"  {d['name']} ({d['bytes']/1024:.1f} Ko)")

