from pathlib import Path
import numpy as np
import pandas as pd
SEED = 42
rng = np.random.default_rng(SEED)
OUTPUT = Path("output")
OUTPUT.mkdir(exist_ok=True)
INPUTS = {key: str(Path("inputs") / key) for key in ['pf_52f5f44d6e9445e3a7770109', 'pf_e4d1474ecfc343eb985dd3db', 'pf_3114413445ac45e58de8365d', 'pf_3fe5d5440a6d49069850f08f', 'pf_633225b80e1043e7b8c37c60', 'pf_0dcdc3366f1d44bdabdc55e2', 'pf_c1e2e939b13f4b52b95a55c8', 'pf_eaab43a437ce4fd98e8aab4c', 'pf_67c4a322514b40ae97c9e338', 'pf_ffe8be2fc7ba44fba4ad6295', 'pf_3e7e7ad8ef744a279f4fd16b', 'pf_5cf29ec2a5e24af4b1f3b4ab', 'pf_0f364ac85e064af2a8351df1', 'pf_6f931b49d0b74134a5d02993', 'pf_c03964b001d14c57919e486b', 'pf_d9e04e5cb85b46f5ac6180ba', 'dat_5b0f9cf44bf6', 'dat_c7fb5876956c', 'dat_b5ab13cee7be', 'dat_a23efbae3451', 'dat_89ef65c5b6df', 'dat_bbef191980a3', 'dat_106438afb1ed', 'dat_9ed6ee755b75', 'dat_030266797f68', 'dat_734383a79cf7', 'dat_30d484458ace']}
def progress(message="", **fields):
    import json as _j, sys as _s, time as _t
    try:
        _r = dict(fields, message=str(message)[:200], t=round(_t.time(), 2))
        _l = _j.dumps(_r, default=str)
        print("[progress] " + _l, flush=True)
        with open(OUTPUT / ".progress.jsonl", "a") as _f:
            _f.write(_l + "\n")
    except Exception:
        pass
def _rt_setup():
    import json as _j, sys as _s
    here = globals().get("__file__")
    try:
        pd.set_option("future.infer_string", False)
        _select = pd.DataFrame.select_dtypes

        def select_dtypes(self, include=None, exclude=None):
            def classic(value):
                if value is None:
                    return None
                items = list(value) if isinstance(value, (list, tuple, set, frozenset)) else [value]
                out = []
                for item in items:
                    if item is str or (isinstance(item, str) and item in ("str", "string")):
                        out.append(object)
                        if item == "string":
                            out.append(item)
                    else:
                        out.append(item)
                return [x for i, x in enumerate(out) if not any(x is y for y in out[:i])]
            return _select(self, include=classic(include), exclude=classic(exclude))
        pd.DataFrame.select_dtypes = select_dtypes
    except Exception:
        pass
    _base = _j.JSONEncoder.default

    def default(self, value):
        if isinstance(value, np.generic):
            return value.item()
        if isinstance(value, np.ndarray):
            return value.tolist()
        if isinstance(value, (pd.Series, pd.Index)):
            return value.tolist()
        if isinstance(value, pd.DataFrame):
            return value.to_dict(orient="records")
        if isinstance(value, (pd.Timestamp, pd.Timedelta, Path)):
            return str(value)
        if isinstance(value, (set, frozenset)):
            return sorted(value, key=str)
        if value is pd.NA or value is pd.NaT:
            return None
        return _base(self, value)
    _j.JSONEncoder.default = default

    def diagnose(kind, error, tb):
        import re as _r, difflib as _d
        lines, message, frames, seen = [], str(error), [], set()

        def collect(space):
            for key, value in list(space.items()):
                if isinstance(value, pd.DataFrame) and id(value) not in seen and not str(key).startswith("_"):
                    seen.add(id(value))
                    frames.append((str(key), value))
        step = tb
        while step is not None:
            if step.tb_frame.f_code.co_filename == here:
                collect(step.tb_frame.f_locals)
            step = step.tb_next
        collect(globals())
        frames = frames[:8]

        def text_columns(frame):
            return [c for c in frame.columns if not (pd.api.types.is_numeric_dtype(frame[c])
                    or pd.api.types.is_bool_dtype(frame[c]) or pd.api.types.is_datetime64_any_dtype(frame[c]))]
        if "could not convert string to" in message:
            told = {}
            for label, frame in frames:
                columns = tuple(str(c) for c in text_columns(frame))
                if columns:
                    told.setdefault(columns, []).append((label, frame))
            value = _r.search(r"could not convert string to \w+: '?([^']*)'?", message)
            value = value.group(1) if value else None
            for columns, where in list(told.items())[:2]:
                frame = where[0][1]
                holds = [c for c in columns if value and c in frame.columns
                         and bool((frame[c].astype(str) == value).any())]
                if holds:
                    lines.append(f"{value!r} is a value of column {', '.join(holds[:3])}.")
                shown = "; ".join(
                    f"{c} (values: {', '.join(str(v)[:24] for v in frame[c].dropna().unique()[:4])})"
                    for c in columns[:8])
                lines.append(
                    f"Text columns in {', '.join(label for label, _ in where[:4])}: {shown}. They reached a model "
                    "that needs numbers. Encode exactly these columns by name inside the model pipeline "
                    "(ColumnTransformer with OneHotEncoder(handle_unknown='ignore'), fitted on the training rows "
                    "only), or leave them out of the features. A table read back from CSV holds the text again: "
                    "an encoding done in an earlier call is not in the file unless the encoded columns were saved.")
        if kind.__name__ == "KeyError" and error.args and isinstance(error.args[0], str):
            key = error.args[0]
            for label, frame in frames[:3]:
                names = [str(c) for c in frame.columns]
                if key not in names:
                    close = _d.get_close_matches(key, names, n=4, cutoff=0.5)
                    lines.append(f"{label} has no column {key!r}."
                                 + (f" Nearest names: {', '.join(close)}." if close else "")
                                 + f" Its columns: {', '.join(names[:60])}.")
            try:
                if key not in INPUTS and not lines:
                    lines.append("INPUTS holds: " + ", ".join(sorted(str(k) for k in INPUTS)[:30]) + ".")
            except Exception:
                pass
        if "NaN" in message or "missing values" in message or "infinity" in message:
            for label, frame in frames[:4]:
                empty = frame.isna().sum()
                empty = empty[empty > 0].sort_values(ascending=False)
                if len(empty):
                    lines.append(f"Missing values in {label}: "
                                 + ", ".join(f"{c} {int(n)}" for c, n in empty.head(10).items()) + ".")
        if kind.__name__ == "NameError":
            lines.append("Every call is a new program: variables, fitted models and imports of an earlier call do "
                         "not exist here. Define the name in this program, or read what an earlier call saved "
                         "from INPUTS by its file name.")
        if "inconsistent numbers of samples" in message or "shape" in message.lower() or "feature names" in message.lower():
            if frames:
                lines.append("Shapes: " + ", ".join(f"{label} {tuple(frame.shape)}" for label, frame in frames) + ".")
        try:
            from importlib import metadata as _m
            found = []
            for library in ("pandas", "numpy", "scikit-learn", "xgboost", "lightgbm", "catboost", "optuna",
                            "scipy", "matplotlib"):
                try:
                    found.append(library + " " + _m.version(library))
                except Exception:
                    pass
            if found:
                lines.append("Installed versions: " + ", ".join(found) + ".")
        except Exception:
            pass
        return lines

    def stopped(kind, error, tb):
        import traceback as _t
        _t.print_exception(kind, error, tb)
        try:
            for line in diagnose(kind, error, tb):
                print("[diagnosis] " + str(line)[:900], file=_s.stderr)
        except Exception:
            pass
        _s.stderr.flush()
    _s.excepthook = stopped


_rt_setup()

import zipfile, json, hashlib
from pathlib import Path

# Known pf_ ID → name mapping (from project file listing)
PF_MAP = {
    'pf_e4d1474ecfc343eb985dd3db': '56_classe_a_fiches_detaillees.md',
    'pf_3114413445ac45e58de8365d': '58_plan_A1_soil_nowcast.md',
    'pf_3fe5d5440a6d49069850f08f': '80_smartagri_ai_orchestrator.md',
    'pf_633225b80e1043e7b8c37c60': '81_ai_execution_flows.md',
    'pf_0dcdc3366f1d44bdabdc55e2': '82_class_b_readiness.md',
    'pf_c1e2e939b13f4b52b95a55c8': 'rapport_analyse_bundle_smartagri92.md',
    'pf_eaab43a437ce4fd98e8aab4c': 'lgb_config.json',
    'pf_67c4a322514b40ae97c9e338': 'lgb_feature_importance.png',
    'pf_ffe8be2fc7ba44fba4ad6295': 'A2_ET0_Forecast_models.zip',
    'pf_3e7e7ad8ef744a279f4fd16b': 'A3_Yield_A5_Price_models.zip',
    'pf_5cf29ec2a5e24af4b1f3b4ab': 'A6_A7_A9_models.zip',
    'pf_0f364ac85e064af2a8351df1': 'analysis_part1.json',
    'pf_6f931b49d0b74134a5d02993': 'quality_issues_orig.csv',
    'pf_c03964b001d14c57919e486b': 'inventaire_datasets_orig.csv',
    'pf_d9e04e5cb85b46f5ac6180ba': 'lgb_fold_metrics_orig.csv',
}

def classify(name):
    ext = Path(name).suffix.lower()
    if ext == '.md': return 'documents'
    elif ext == '.csv': return 'tables'
    elif ext == '.json': return 'configs'
    elif ext == '.png': return 'figures'
    elif ext == '.zip': return 'models'
    return 'other'

# === STEP 1: Read pass1 ZIP ===
entries = {}  # arcname -> bytes
seen_hashes = set()

pass1_path = INPUTS['smartagri_export_pass1.zip']
with zipfile.ZipFile(pass1_path, 'r') as zf:
    for info in zf.infolist():
        if info.is_dir():
            continue
        data = zf.read(info.filename)
        h = hashlib.sha256(data).hexdigest()[:20]
        
        # Resolve pf_ names in other/ folder
        basename = info.filename.split('/')[-1]
        if basename in PF_MAP:
            real_name = PF_MAP[basename]
            folder = classify(real_name)
            arcname = f"{folder}/{real_name}"
        elif basename.startswith('pf_'):
            # Try to detect from content
            try:
                text = data.decode('utf-8')[:200]
                if text.startswith('#'):
                    # It's a markdown doc — extract title
                    title = text.split('\n')[0].strip('# ').strip()
                    safe = title[:60].replace(' ', '_').replace('/', '_')
                    arcname = f"documents/{safe}.md"
                else:
                    arcname = f"other/{basename}"
            except:
                arcname = f"other/{basename}"
        else:
            arcname = info.filename
        
        if h not in seen_hashes:
            seen_hashes.add(h)
            entries[arcname] = data

progress("Pass1 lue et résolue", done=1, total=4, files=len(entries))

# === STEP 2: Add new inputs ===
for name, path in sorted(INPUTS.items()):
    if name == 'smartagri_export_pass1.zip':
        continue
    
    data = Path(path).read_bytes()
    h = hashlib.sha256(data).hexdigest()[:20]
    
    if h in seen_hashes:
        continue
    seen_hashes.add(h)
    
    real_name = PF_MAP.get(name, name)
    if real_name.startswith('dat_'):
        continue
    
    folder = classify(real_name)
    arcname = f"{folder}/{real_name}"
    entries[arcname] = data

progress("Nouveaux fichiers ajoutés", done=2, total=4, files=len(entries))

# === STEP 3: Add README ===
readme = """# SmartAgri92 — Export Complet du Projet
## PAS Challenge 2026 — Équipe Agri-Moderne 5.0

### Contenu de ce ZIP

#### documents/ — Architecture, plans et rapports
Tous les documents .md produits (56 à 93) : portfolio IA, plans d'entraînement,
rapports de validation, architecture système, MLOps, assistant, monitoring, etc.

#### tables/ — Métriques et résultats mesurés
Les 27 tables CSV : métriques par fold, importance des features, erreurs par groupe,
résultats SHAP, clustering, chunks knowledge, évaluations.

#### models/ — Artefacts de modèles entraînés
ZIPs des modèles XGBoost/CatBoost (ET0, Yield, Price, Crop Calendar, NDVI, Clustering).
**Note** : lgb_models_native.zip (54 Mo, modèles LightGBM SoilNowcast) est disponible
séparément dans les Fichiers du projet OctOpus (trop volumineux pour ce ZIP).

#### configs/ — Configurations
lgb_config.json, analysis_part1.json et autres configs.

#### figures/ — Visualisations
Graphiques d'importance des features, visualisations des résultats.

### 9 Modèles Champion
| # | Modèle | Champion | Métrique |
|---|--------|----------|----------|
| A1 | SoilNowcast | LightGBM | R²=0.8375 |
| A2 | ET0 Forecast | CatBoost | R²=0.9997 |
| A3 | Yield Forecast | CatBoost | R²=0.951 |
| A4 | Rain Intelligence | CatBoost | AUC=0.963 |
| A5 | Price Forecast | XGBoost | R²=0.900 |
| A6 | Crop Calendar | CatBoost | F1=0.980 |
| A7 | NDVI Anomaly | LightGBM | F1=0.994 |
| A8 | Anomaly Intelligence | IsoForest+AE | F1=0.85 |
| A9 | Market Clustering | KMeans | Sil=0.345 |

### Fichiers volumineux (télécharger séparément depuis OctOpus)
- `lgb_models_native.zip` (54 Mo) — 15 modèles LightGBM entraînés (SoilNowcast)
- `octopus_import_bundle.zip` (39 Mo) — Data Lake complet (28 datasets)

### Données
- 28 datasets réels : NASA POWER, CHIRPS, FAOSTAT, WFP, iSDAsoil, ESA, Sentinel-2
- 30+ millions de lignes, 14/14 régions du Sénégal
- Zéro donnée synthétique

### Reconstruction hors OctOpus
1. Installer Python 3.11+ avec pandas, scikit-learn, lightgbm, xgboost, catboost
2. Charger les tables CSV (métriques, features, évaluations)
3. Charger les modèles depuis les ZIPs (joblib/pickle)
4. Suivre 84_smartagri_mlops_architecture.md pour le pipeline
5. Suivre 82_smartagri_ai_runtime.md pour l'orchestrateur
"""
entries['README.md'] = readme.encode('utf-8')

# Add manifest
manifest = {
    'project': 'SmartAgri92',
    'challenge': 'PAS Challenge 2026',
    'team': 'Agri-Moderne 5.0',
    'members': ['Mouhamadou Diop', 'Moustapha Diallo'],
    'models_trained': 9,
    'datasets': 28,
    'total_rows': '30+ millions',
    'regions': '14/14 Sénégal',
    'files_in_zip': len(entries),
    'folders': {f: len([k for k in entries if k.startswith(f + '/')]) 
                for f in sorted(set(k.split('/')[0] for k in entries if '/' in k))},
    'separate_downloads': [
        'lgb_models_native.zip (54 Mo) — modèles LightGBM SoilNowcast',
        'octopus_import_bundle.zip (39 Mo) — Data Lake complet'
    ]
}
entries['manifest.json'] = json.dumps(manifest, indent=2, ensure_ascii=False).encode('utf-8')

progress("README et manifest ajoutés", done=3, total=4, files=len(entries))

# === STEP 4: Write final ZIP ===
out = OUTPUT / "smartagri_complete_export.zip"
with zipfile.ZipFile(out, 'w', zipfile.ZIP_DEFLATED) as zf:
    for arcname in sorted(entries.keys()):
        zf.writestr(arcname, entries[arcname])

progress("ZIP final écrit", done=4, total=4)

size_kb = out.stat().st_size / 1024
print(f"\n=== EXPORT FINAL SMARTAGRI92 ===")
print(f"Taille : {size_kb:.0f} Ko ({size_kb/1024:.1f} Mo)")
print(f"Fichiers uniques : {len(entries)}")
print()
for folder in sorted(set(k.split('/')[0] for k in entries if '/' in k)):
    items = sorted([k for k in entries if k.startswith(folder + '/')])
    total = sum(len(entries[k]) for k in items) / 1024
    print(f"  {folder}/ : {len(items)} fichiers ({total:.0f} Ko)")
    for k in items:
        print(f"    └─ {k.split('/')[-1]} ({len(entries[k])/1024:.0f} Ko)")
print(f"\n  README.md + manifest.json")

