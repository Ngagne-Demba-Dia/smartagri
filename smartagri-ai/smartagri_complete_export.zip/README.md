# SmartAgri92 — Export Complet du Projet
## PAS Challenge 2026 — Équipe Agri-Moderne 5.0

### Contenu de ce ZIP

#### documents/ — Architecture, plans et rapports
Tous les documents .md produits (56 à 93) : portfolio IA, plans d'entraînement,
rapports de validation, architecture système, MLOps, assistant, monitoring, etc.

#### tables/ — Métriques et résultats mesurés
Les 27 tables CSV : métriques par fold, importance des features, erreurs par groupe,
résultats SHAP, clustering, chunks knowledge, évaluations.

#### models/ — Artefacts de modèles entraînés
ZIPs des modèles XGBoost/CatBoost (ET0, Yield, Price, Crop Calendar, NDVI, Clustering).
**Note** : lgb_models_native.zip (54 Mo, modèles LightGBM SoilNowcast) est disponible
séparément dans les Fichiers du projet OctOpus (trop volumineux pour ce ZIP).

#### configs/ — Configurations
lgb_config.json, analysis_part1.json et autres configs.

#### figures/ — Visualisations
Graphiques d'importance des features, visualisations des résultats.

### 9 Modèles Champion
| # | Modèle | Champion | Métrique |
|---|--------|----------|----------|
| A1 | SoilNowcast | LightGBM | R²=0.8375 |
| A2 | ET0 Forecast | CatBoost | R²=0.9997 |
| A3 | Yield Forecast | CatBoost | R²=0.951 |
| A4 | Rain Intelligence | CatBoost | AUC=0.963 |
| A5 | Price Forecast | XGBoost | R²=0.900 |
| A6 | Crop Calendar | CatBoost | F1=0.980 |
| A7 | NDVI Anomaly | LightGBM | F1=0.994 |
| A8 | Anomaly Intelligence | IsoForest+AE | F1=0.85 |
| A9 | Market Clustering | KMeans | Sil=0.345 |

### Fichiers volumineux (télécharger séparément depuis OctOpus)
- `lgb_models_native.zip` (54 Mo) — 15 modèles LightGBM entraînés (SoilNowcast)
- `octopus_import_bundle.zip` (39 Mo) — Data Lake complet (28 datasets)

### Données
- 28 datasets réels : NASA POWER, CHIRPS, FAOSTAT, WFP, iSDAsoil, ESA, Sentinel-2
- 30+ millions de lignes, 14/14 régions du Sénégal
- Zéro donnée synthétique

### Reconstruction hors OctOpus
1. Installer Python 3.11+ avec pandas, scikit-learn, lightgbm, xgboost, catboost
2. Charger les tables CSV (métriques, features, évaluations)
3. Charger les modèles depuis les ZIPs (joblib/pickle)
4. Suivre 84_smartagri_mlops_architecture.md pour le pipeline
5. Suivre 82_smartagri_ai_runtime.md pour l'orchestrateur
