from pathlib import Path
import numpy as np
import pandas as pd
SEED = 42
rng = np.random.default_rng(SEED)
OUTPUT = Path("output")
OUTPUT.mkdir(exist_ok=True)
INPUTS = {key: str(Path("inputs") / key) for key in ['pf_379cabbda1aa439f8cab8a9a', 'pf_e4d1474ecfc343eb985dd3db', 'pf_c1e2e939b13f4b52b95a55c8', 'pf_eaab43a437ce4fd98e8aab4c', 'pf_0f364ac85e064af2a8351df1', 'pf_67c4a322514b40ae97c9e338', 'pf_6f931b49d0b74134a5d02993', 'pf_c03964b001d14c57919e486b', 'dat_1b06400c0a9d', 'dat_960302d77246', 'dat_266cbb9747a3', 'dat_0927e7a5f87c', 'dat_7764b6dc996a', 'dat_89ef65c5b6df', 'dat_a23efbae3451', 'dat_bbef191980a3']}
def progress(message="", **fields):
    import json as _j, sys as _s, time as _t
    try:
        _r = dict(fields, message=str(message)[:200], t=round(_t.time(), 2))
        _l = _j.dumps(_r, default=str)
        print("[progress] " + _l, flush=True)
        with open(OUTPUT / ".progress.jsonl", "a") as _f:
            _f.write(_l + "\n")
    except Exception:
        pass
def _rt_setup():
    import json as _j, sys as _s
    here = globals().get("__file__")
    try:
        pd.set_option("future.infer_string", False)
        _select = pd.DataFrame.select_dtypes

        def select_dtypes(self, include=None, exclude=None):
            def classic(value):
                if value is None:
                    return None
                items = list(value) if isinstance(value, (list, tuple, set, frozenset)) else [value]
                out = []
                for item in items:
                    if item is str or (isinstance(item, str) and item in ("str", "string")):
                        out.append(object)
                        if item == "string":
                            out.append(item)
                    else:
                        out.append(item)
                return [x for i, x in enumerate(out) if not any(x is y for y in out[:i])]
            return _select(self, include=classic(include), exclude=classic(exclude))
        pd.DataFrame.select_dtypes = select_dtypes
    except Exception:
        pass
    _base = _j.JSONEncoder.default

    def default(self, value):
        if isinstance(value, np.generic):
            return value.item()
        if isinstance(value, np.ndarray):
            return value.tolist()
        if isinstance(value, (pd.Series, pd.Index)):
            return value.tolist()
        if isinstance(value, pd.DataFrame):
            return value.to_dict(orient="records")
        if isinstance(value, (pd.Timestamp, pd.Timedelta, Path)):
            return str(value)
        if isinstance(value, (set, frozenset)):
            return sorted(value, key=str)
        if value is pd.NA or value is pd.NaT:
            return None
        return _base(self, value)
    _j.JSONEncoder.default = default

    def diagnose(kind, error, tb):
        import re as _r, difflib as _d
        lines, message, frames, seen = [], str(error), [], set()

        def collect(space):
            for key, value in list(space.items()):
                if isinstance(value, pd.DataFrame) and id(value) not in seen and not str(key).startswith("_"):
                    seen.add(id(value))
                    frames.append((str(key), value))
        step = tb
        while step is not None:
            if step.tb_frame.f_code.co_filename == here:
                collect(step.tb_frame.f_locals)
            step = step.tb_next
        collect(globals())
        frames = frames[:8]

        def text_columns(frame):
            return [c for c in frame.columns if not (pd.api.types.is_numeric_dtype(frame[c])
                    or pd.api.types.is_bool_dtype(frame[c]) or pd.api.types.is_datetime64_any_dtype(frame[c]))]
        if "could not convert string to" in message:
            told = {}
            for label, frame in frames:
                columns = tuple(str(c) for c in text_columns(frame))
                if columns:
                    told.setdefault(columns, []).append((label, frame))
            value = _r.search(r"could not convert string to \w+: '?([^']*)'?", message)
            value = value.group(1) if value else None
            for columns, where in list(told.items())[:2]:
                frame = where[0][1]
                holds = [c for c in columns if value and c in frame.columns
                         and bool((frame[c].astype(str) == value).any())]
                if holds:
                    lines.append(f"{value!r} is a value of column {', '.join(holds[:3])}.")
                shown = "; ".join(
                    f"{c} (values: {', '.join(str(v)[:24] for v in frame[c].dropna().unique()[:4])})"
                    for c in columns[:8])
                lines.append(
                    f"Text columns in {', '.join(label for label, _ in where[:4])}: {shown}. They reached a model "
                    "that needs numbers. Encode exactly these columns by name inside the model pipeline "
                    "(ColumnTransformer with OneHotEncoder(handle_unknown='ignore'), fitted on the training rows "
                    "only), or leave them out of the features. A table read back from CSV holds the text again: "
                    "an encoding done in an earlier call is not in the file unless the encoded columns were saved.")
        if kind.__name__ == "KeyError" and error.args and isinstance(error.args[0], str):
            key = error.args[0]
            for label, frame in frames[:3]:
                names = [str(c) for c in frame.columns]
                if key not in names:
                    close = _d.get_close_matches(key, names, n=4, cutoff=0.5)
                    lines.append(f"{label} has no column {key!r}."
                                 + (f" Nearest names: {', '.join(close)}." if close else "")
                                 + f" Its columns: {', '.join(names[:60])}.")
            try:
                if key not in INPUTS and not lines:
                    lines.append("INPUTS holds: " + ", ".join(sorted(str(k) for k in INPUTS)[:30]) + ".")
            except Exception:
                pass
        if "NaN" in message or "missing values" in message or "infinity" in message:
            for label, frame in frames[:4]:
                empty = frame.isna().sum()
                empty = empty[empty > 0].sort_values(ascending=False)
                if len(empty):
                    lines.append(f"Missing values in {label}: "
                                 + ", ".join(f"{c} {int(n)}" for c, n in empty.head(10).items()) + ".")
        if kind.__name__ == "NameError":
            lines.append("Every call is a new program: variables, fitted models and imports of an earlier call do "
                         "not exist here. Define the name in this program, or read what an earlier call saved "
                         "from INPUTS by its file name.")
        if "inconsistent numbers of samples" in message or "shape" in message.lower() or "feature names" in message.lower():
            if frames:
                lines.append("Shapes: " + ", ".join(f"{label} {tuple(frame.shape)}" for label, frame in frames) + ".")
        try:
            from importlib import metadata as _m
            found = []
            for library in ("pandas", "numpy", "scikit-learn", "xgboost", "lightgbm", "catboost", "optuna",
                            "scipy", "matplotlib"):
                try:
                    found.append(library + " " + _m.version(library))
                except Exception:
                    pass
            if found:
                lines.append("Installed versions: " + ", ".join(found) + ".")
        except Exception:
            pass
        return lines

    def stopped(kind, error, tb):
        import traceback as _t
        _t.print_exception(kind, error, tb)
        try:
            for line in diagnose(kind, error, tb):
                print("[diagnosis] " + str(line)[:900], file=_s.stderr)
        except Exception:
            pass
        _s.stderr.flush()
    _s.excepthook = stopped


_rt_setup()

import zipfile, os
from pathlib import Path

# === Gather all available inputs ===
available = {}
for k in INPUTS:
    available[k] = INPUTS[k]
print("Available inputs:", sorted(available.keys()))

# === Build the ZIP ===
zip_path = OUTPUT / "smartagri_complementary_bundle.zip"

# App source manifest
app_files = [
    "src/App.tsx", "src/components/ChampionBadge.tsx", "src/components/Explainer.tsx",
    "src/components/JuryDemo.tsx", "src/components/MetricCard.tsx", "src/components/PageHeader.tsx",
    "src/components/Sidebar.tsx", "src/components/TopBar.tsx", "src/index.css",
    "src/pages/AssistantIA.tsx", "src/pages/CarteSenegal.tsx", "src/pages/Dashboard.tsx",
    "src/pages/ImpactMetriques.tsx", "src/pages/Irrigation.tsx", "src/pages/KnowledgeExplorer.tsx",
    "src/pages/Monitoring.tsx", "src/pages/RainIntelligence.tsx", "src/pages/ScenarioSimulator.tsx",
    "src/pages/SoilNowcast.tsx",
]

app_manifest = "# SmartAgri92 Demo App — Source (v2)\n\nURL: https://octopus.ml/a/new-app-771f89\n\n## Files\n\n"
for f in app_files:
    app_manifest += f"- {f}\n"
app_manifest += "\n## To run locally\n\nReplace octopus.db.query() with local REST API.\nReplace octopus.ask() with local RAG over 527 knowledge chunks.\n"

readme = """# SmartAgri92 — Bundle Complémentaire

Actifs manquants de smartagri_complete_ai_bundle.zip (281 Ko).

## Structure
- 1_documentation/ : docs manquants
- 3_metrics/ : group_errors, fold_stability, anomaly
- 6_knowledge/ : 527 chunks + 20 évaluations  
- 8_configs/ : JSON configs, quality, inventaire
- 8_figures/ : feature importance PNG
- 9_app_source/ : manifeste App Demo
- 10_manifest/ : 94_missing_local_assets.md

## Téléchargements séparés (trop volumineux)
- lgb_models_native.zip (54 Mo)
- octopus_import_bundle.zip (39 Mo)
- SoilNowcast — LightGBM.zip (58 Mo)

## Reconstruction : 4 fichiers suffisent
1. smartagri_complete_ai_bundle.zip (281 Ko)
2. smartagri_complementary_bundle.zip (ce fichier)
3. lgb_models_native.zip (54 Mo)
4. octopus_import_bundle.zip (39 Mo)
"""

# File mapping: destination -> input key
file_map = {
    # 1. Documentation
    "1_documentation/56_classe_a_fiches_detaillees.md": "56_classe_a_fiches_detaillees.md",
    "1_documentation/rapport_analyse_bundle_smartagri92.md": "rapport_analyse_bundle_smartagri92.md",
    # 3. Metrics (missing group errors + fold stability)
    "3_metrics/soilnowcast_group_errors.csv": "soilnowcast_group_errors.csv",
    "3_metrics/et0_forecast_group_errors.csv": "et0_forecast_group_errors.csv",
    "3_metrics/wx_rain_prob_group_errors.csv": "wx_rain_prob_group_errors.csv",
    "3_metrics/wx_rain_prob_fold_stability.csv": "wx_rain_prob_fold_stability.csv",
    "3_metrics/price_forecast_group_errors.csv": "price_forecast_group_errors.csv",
    "3_metrics/anomaly_intelligence_metrics.csv": "anomaly_intelligence_metrics.csv",
    "3_metrics/anomaly_intelligence_feature_importance.csv": "anomaly_intelligence_feature_importance.csv",
    # 6. Knowledge
    "6_knowledge/smartagri_knowledge_chunks.csv": "smartagri_knowledge_chunks.csv",
    "6_knowledge/smartagri_knowledge_eval.csv": "smartagri_knowledge_eval.csv",
    # 8. Configs
    "8_configs/quality_issues.csv": "quality_issues.csv",
    "8_configs/inventaire_datasets.csv": "inventaire_datasets.csv",
    "8_configs/lgb_config.json": "lgb_config.json",
    "8_configs/analysis_part1.json": "analysis_part1.json",
    # 8. Figures
    "8_figures/lgb_feature_importance.png": "lgb_feature_importance.png",
    # 10. Manifest
    "10_manifest/94_missing_local_assets.md": "94_missing_local_assets.md",
}

with zipfile.ZipFile(zip_path, 'w', zipfile.ZIP_DEFLATED) as zf:
    added = 0
    for dest, key in file_map.items():
        if key in available:
            zf.write(available[key], dest)
            added += 1
        else:
            print(f"  SKIP (not available): {key}")

    # 9. App source
    zf.writestr("9_app_source/APP_SOURCE_MANIFEST.md", app_manifest)
    added += 1

    # README
    zf.writestr("README.md", readme)
    added += 1

progress("ZIP built", done=1, total=1)

zip_size = os.path.getsize(zip_path)
with zipfile.ZipFile(zip_path, 'r') as zf:
    members = zf.namelist()

print(f"\n{'='*60}")
print(f"smartagri_complementary_bundle.zip: {zip_size/1024:.1f} Ko, {len(members)} fichiers")
print(f"{'='*60}")
for m in sorted(members):
    try:
        info = zf.getinfo(m)
        sz = info.file_size
        print(f"  {m} ({sz/1024:.1f} Ko)" if sz > 512 else f"  {m}")
    except:
        print(f"  {m}")

